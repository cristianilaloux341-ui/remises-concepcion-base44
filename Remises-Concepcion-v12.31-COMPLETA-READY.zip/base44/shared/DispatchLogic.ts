export const defaultFailureInjector = { hit: async (point: string) => {} };

export async function releaseManualDriver(b44: any, driverId: string, orderId: string, token: string) {
  await b44.entities.Driver.updateMany(
    { id: driverId, manual_reservation_token: token },
    { $set: { dispatch_status: 'normal', reserved_order_id: null, manual_reservation_token: null } }
  );
}

export async function safeAuditLog(b44: any, data: any, failureInjector = defaultFailureInjector) {
  try {
    await failureInjector.hit('DURING_AUDIT_LOG');
    await b44.entities.AuditLog.create(data);
  } catch (e) {
    console.error("Fallo no destructivo en AuditLog:", e);
    // Fallback log de sistema
  }
}

export async function validatePilotDriver(b44: any, zone: string, driverId: string) {
  const configs = await b44.entities.DispatchConfig.filter({ zone });
  const config = configs[0];
  if (config && config.pilotMode && config.engineState !== 'disabled') {
    if (!config.enabledDriverIds || !config.enabledDriverIds.includes(driverId)) {
      throw new Error('DRIVER_NOT_ENABLED_FOR_PILOT');
    }
  }
}

export async function tryManualCandidate(b44: any, baseId: string, order: any, driver: any, token: string, failureInjector = defaultFailureInjector) {
  try {
    await validatePilotDriver(b44, order.zone || '1-Puerto', driver.id);
    // 1. Reservar Driver
    const driverRes = await b44.entities.Driver.updateMany(
      { id: driver.id, status: 'disponible', dispatch_status: 'normal', reserved_order_id: null, active_order_id: null, active_ride_id: null },
      { $set: { dispatch_status: 'manual_pending', reserved_order_id: order.id, manual_reservation_token: token } }
    );
    if ((driverRes.matchedCount ?? driverRes.modifiedCount ?? driverRes.updated ?? 0) !== 1) return false;

    await failureInjector.hit('AFTER_DRIVER_RESERVE');

    // 2. Marcar Viaje
    const rideRes = await b44.entities.RideOrder.updateMany(
      { id: order.id, status: 'procesando_despacho', reservation_token: token },
      { $set: { status: 'esperando_confirmacion_manual', driver_id: null, reserved_driver_id: driver.id, manual_reservation_token: token } }
    );
    if ((rideRes.matchedCount ?? rideRes.modifiedCount ?? rideRes.updated ?? 0) !== 1) {
      await releaseManualDriver(b44, driver.id, order.id, token);
      return false;
    }

    await failureInjector.hit('AFTER_RIDE_MANUAL_TRANSITION');

    // 3. Bloquear Base
    const baseRes = await b44.entities.Base.updateMany(
      { id: baseId, lock_token: token },
      { $set: { dispatch_status: 'esperando_manual', active_order_id: order.id, manual_reservation_token: token, lock_token: null, lock_expires_at: null, manual_requested_at: Date.now(), manual_expires_at: Date.now() + 60000 } }
    );

    if ((baseRes.matchedCount ?? baseRes.modifiedCount ?? baseRes.updated ?? 0) !== 1) {
      // Revertir viaje y chofer
      await b44.entities.RideOrder.updateMany(
        { id: order.id, status: 'esperando_confirmacion_manual', reserved_driver_id: driver.id, manual_reservation_token: token },
        { $set: { status: 'procesando_despacho', driver_id: null, reserved_driver_id: null, manual_reservation_token: null, driver_name: null } }
      );
      await releaseManualDriver(b44, driver.id, order.id, token);
      return false;
    }

    await failureInjector.hit('AFTER_BASE_MANUAL_TRANSFER');
    return true;
  } catch (e) {
    if (e.message.includes('INJECTED_FAILURE_AT_AFTER_DRIVER_RESERVE')) {
      await releaseManualDriver(b44, driver.id, order.id, token);
    } else if (e.message.includes('INJECTED_FAILURE_AT_AFTER_RIDE_MANUAL_TRANSITION')) {
      await b44.entities.RideOrder.updateMany(
        { id: order.id, status: 'esperando_confirmacion_manual', manual_reservation_token: token },
        { $set: { status: 'procesando_despacho', driver_id: null, reserved_driver_id: null, manual_reservation_token: null, driver_name: null } }
      );
      await releaseManualDriver(b44, driver.id, order.id, token);
    }
    throw e;
  }
}

export async function assignDriverToOrderAtomic(b44: any, order: any, driver: any, token: string, failureInjector = defaultFailureInjector) {
  try {
    // assignRide puede traer esta validación en paralelo con el resto de lecturas.
    // Otros consumidores/tests siguen validando aquí normalmente.
    if (!order.__pilotValidated) {
      await validatePilotDriver(b44, order.zone || '1-Puerto', driver.id);
    }
    const driverRes = await b44.entities.Driver.updateMany(
      { id: driver.id, status: 'disponible', dispatch_status: 'normal', reserved_order_id: null, active_order_id: null, active_ride_id: null },
      { $set: { dispatch_status: 'automatic_pending', reserved_order_id: order.id, reservation_token: token } }
    );
    if ((driverRes.matchedCount ?? driverRes.modifiedCount ?? driverRes.updated ?? 0) !== 1) return false;

    await failureInjector.hit('AFTER_AUTO_DRIVER_RESERVE');

    // Persistir TODA la identidad/ventana de la oferta antes del push. Antes se
    // guardaban assignment_attempt/assigned_at/offerExpiresAt después de enviar
    // FCM, abriendo una carrera donde el teléfono podía aceptar contra metadatos viejos.
    const offerSet: any = {
      status: 'ofrecido',
      reservation_token: token,
      driver_id: driver.id,
      reserved_driver_id: driver.id,
      manual_reservation_token: null
    };
    for (const field of ['driver_name', 'assigned_base', 'assigned_at', 'offerExpiresAt', 'assignment_attempt', 'offered_driver_ids', 'notes', 'push_ack_at', 'push_ack_assignment_attempt', 'alert_presented_at', 'alert_presented_assignment_attempt', 'alert_presented_protocol_attempt', 'delivery_retry_count']) {
      if (order[field] !== undefined) offerSet[field] = order[field];
    }

    const rideRes = await b44.entities.RideOrder.updateMany(
      { 
        id: order.id,
        status: { $in: ['pendiente', 'procesando_despacho', 'ofrecido'] },
        $and: [
          {
            $or: [
              { reservation_token: null },
              { reservation_token: { $exists: false } },
              { reservation_token: order.reservation_token || null }
            ]
          },
          {
            // No reasignar mientras ACEPTAR / RECHAZAR / TIMEOUT posee el viaje.
            // Sin esta barrera una asignación de Central podía entrar en mitad del
            // rechazo anterior y dejar driver_id de un móvil y reserved_driver_id de otro.
            $or: [
              { processingOwnerId: null },
              { processingOwnerId: { $exists: false } },
              { processingLeaseExpiresAt: { $lt: Date.now() } }
            ]
          }
        ]
      },
      { $set: offerSet }
    );
    if ((rideRes.matchedCount ?? rideRes.modifiedCount ?? rideRes.updated ?? 0) !== 1) {
      await b44.entities.Driver.updateMany({ id: driver.id, reservation_token: token }, { $set: { dispatch_status: 'normal', reserved_order_id: null, reservation_token: null } });
      return false;
    }

    await failureInjector.hit('AFTER_RIDE_OFFER');
    await failureInjector.hit('BEFORE_PUSH');

    // Auditoría y FCM arrancan en paralelo: la escritura del log no debe retrasar
    // la salida del pasaje al teléfono. La oferta ya quedó persistida arriba.
    const assignmentAudit = safeAuditLog(b44, {
      action: 'RIDE_ASSIGNED',
      user_type: 'sistema',
      user_name: 'DispatchLogic',
      details: `Viaje ${order.id} asignado a ${driver.id}`
    }, failureInjector);

    // Trigger directo a sendPushNotification restaurado para eliminar la latencia de la automatización
    try {
      const pushPromise = b44.functions.invoke('sendPushNotification', {
        action: 'send',
        driverId: driver.id,
        orderId: order.id,
        orderData: {
          pickup_address: order.pickup_address,
          dropoff_address: order.dropoff_address,
          fare: order.fare,
          notes: order.notes,
          assignmentAttempt: order.assignment_attempt || 1
        },
        internalKey: Deno.env.get("INTERNAL_SERVICE_KEY")
      });
      const [pushResult] = await Promise.all([pushPromise, assignmentAudit]);

      if (pushResult && pushResult.data && pushResult.data.ok === false) {
         console.warn("Push devolvió false, ignorando para evitar rollback prematuro:", pushResult.data.error || pushResult.data.reason);
      }
    } catch (pushErr) {
      console.error("Error trigger push en DispatchLogic:", pushErr);
      // Eliminado el Failsafe de purga inmediata. El temporizador de 60s se encargará si el chofer no responde.
      await safeAuditLog(b44, { action: 'DELIVERY_WARNING', user_type: 'sistema', user_name: 'System', details: 'Fallo push, pero se mantiene asignación: ' + pushErr.message }, failureInjector);
    }
    
    return true;
  } catch (e) {
    if (e.message.includes('INJECTED_FAILURE_AT_AFTER_AUTO_DRIVER_RESERVE')) {
      await b44.entities.Driver.updateMany({ id: driver.id, reservation_token: token }, { $set: { dispatch_status: 'normal', reserved_order_id: null, reservation_token: null } });
    } else {
      // Revert ride back to procesando_despacho and release driver (for any other error to prevent stuck state)
      await b44.entities.RideOrder.updateMany({ id: order.id, status: 'ofrecido', reservation_token: token }, { $set: { status: 'procesando_despacho', driver_id: null, reserved_driver_id: null, driver_name: null } });
      await b44.entities.Driver.updateMany({ id: driver.id, reservation_token: token }, { $set: { dispatch_status: 'normal', reserved_order_id: null, reservation_token: null } });
      if (e.message.includes('INJECTED_FAILURE_AT_BEFORE_PUSH')) {
        await safeAuditLog(b44, { action: 'DELIVERY_ERROR', user_type: 'sistema', user_name: 'System', details: e.message }, failureInjector);
      }
    }
    throw e;
  }
}

export async function reassignAfterAutomaticReject(b44: any, baseId: string, orderId: string, driverId: string, oldToken: string, failureInjector = defaultFailureInjector) {
  const orderCheck = await b44.entities.RideOrder.get(orderId);
  await validatePilotDriver(b44, orderCheck?.zone || '1-Puerto', driverId);
  const newToken = crypto.randomUUID();
  let ownershipTransferred = false;

  const baseRes = await b44.entities.Base.updateMany(
    { id: baseId, dispatch_status: 'libre' },
    { $set: { dispatch_status: 'procesando', lock_token: newToken, lock_expires_at: Date.now() + 8000, active_order_id: orderId } }
  );
  if ((baseRes.matchedCount ?? baseRes.modifiedCount ?? baseRes.updated ?? 0) !== 1) return { status: 'zone_busy' };

  try {
    await failureInjector.hit('DURING_TOKEN_TRANSFER');
    const orderRes = await b44.entities.RideOrder.updateMany(
      { id: orderId, status: 'ofrecido', reserved_driver_id: driverId, reservation_token: oldToken },
      { $set: { status: 'procesando_despacho', reservation_token: newToken, driver_id: null, reserved_driver_id: null, driver_name: null }, $push: { offered_driver_ids: driverId }, $inc: { assignment_attempt: 1 } }
    );
    if ((orderRes.matchedCount ?? orderRes.modifiedCount ?? orderRes.updated ?? 0) !== 1) return { status: 'already_processed' };

    await failureInjector.hit('DURING_DRIVER_RELEASE');
    const driverRes = await b44.entities.Driver.updateMany(
      { id: driverId, dispatch_status: 'automatic_pending', reserved_order_id: orderId, reservation_token: oldToken },
      { $set: { dispatch_status: 'normal', reserved_order_id: null, reservation_token: null } }
    );
    if ((driverRes.matchedCount ?? driverRes.modifiedCount ?? driverRes.updated ?? 0) !== 1) {
      await safeAuditLog(b44, { action: 'INCONSISTENT_STATE', user_type: 'sistema', user_name: 'System', details: 'Fallo al liberar Driver durante rechazo automático' }, failureInjector);
      throw new Error('INCONSISTENT_STATE:DRIVER_RELEASE_FAILED');
    }

    ownershipTransferred = true; // Simulación de continuación
    return { status: 'reassigned' };
  } finally {
    if (!ownershipTransferred) {
      await b44.entities.Base.updateMany(
        { id: baseId, dispatch_status: 'procesando', lock_token: newToken },
        { $set: { dispatch_status: 'libre', lock_token: null, lock_expires_at: null, active_order_id: null } }
      );
    }
  }
}

export async function cleanupExpiredTechnicalLock(b44: any, baseId: string, expectedToken: string, now: number) {
  const base = await b44.entities.Base.get(baseId);
  if (!base || base.dispatch_status === 'esperando_manual' || base.lock_token !== expectedToken) {
    return { status: 'already_recovered', baseId, token: expectedToken };
  }
  if (!base.lock_expires_at || base.lock_expires_at >= now) {
    return { status: 'lock_renewed', baseId, token: expectedToken };
  }

  const drivers = await b44.entities.Driver.filter({ reservation_token: expectedToken });
  if (drivers.length > 0) {
    await b44.entities.Driver.updateMany(
      { id: drivers[0].id, reservation_token: expectedToken },
      { $set: { dispatch_status: 'normal', reserved_order_id: null, reservation_token: null } }
    );
  }

  const orders = await b44.entities.RideOrder.filter({ reservation_token: expectedToken });
  if (orders.length > 0) {
    const ord = orders[0];
    const safeStates = ['aceptado', 'en_camino', 'en_viaje', 'completado'];
    if (!safeStates.includes(ord.status) && !ord.driver_id) {
      await b44.entities.RideOrder.updateMany(
        { id: ord.id, reservation_token: expectedToken },
        { $set: { status: 'pendiente', reservation_token: null, reserved_driver_id: null, driver_name: null } }
      );
    }
  }

  const bRes = await b44.entities.Base.updateMany(
    { id: baseId, lock_token: expectedToken },
    { $set: { dispatch_status: 'libre', lock_token: null, lock_expires_at: null, active_order_id: null } }
  );
  if ((bRes.matchedCount ?? bRes.modifiedCount ?? bRes.updated ?? 0) !== 1) return { status: 'already_recovered', baseId, token: expectedToken };

  return { status: 'recovered', baseId, orderId: orders[0]?.id, driverId: drivers[0]?.id, token: expectedToken };
}

export async function cleanupExpiredManualWait(b44: any, baseId: string, expectedToken: string, now: number) {
  const base = await b44.entities.Base.get(baseId);
  if (!base || base.manual_reservation_token !== expectedToken) return { status: 'already_recovered', baseId, token: expectedToken };
  if (!base.manual_expires_at || base.manual_expires_at >= now) return { status: 'lock_renewed', baseId, token: expectedToken };

  const drivers = await b44.entities.Driver.filter({ manual_reservation_token: expectedToken });
  if (drivers.length > 0) {
    await b44.entities.Driver.updateMany(
      { id: drivers[0].id, manual_reservation_token: expectedToken },
      { $set: { dispatch_status: 'normal', reserved_order_id: null, manual_reservation_token: null } }
    );
  }

  const orders = await b44.entities.RideOrder.filter({ manual_reservation_token: expectedToken });
  if (orders.length > 0) {
    const ord = orders[0];
    const safeStates = ['aceptado', 'en_camino', 'en_viaje', 'completado'];
    if (!safeStates.includes(ord.status) && !ord.driver_id) {
      await b44.entities.RideOrder.updateMany(
        { id: ord.id, manual_reservation_token: expectedToken },
        { $set: { status: 'pendiente', manual_reservation_token: null, reserved_driver_id: null, driver_name: null } }
      );
    }
  }

  const bRes = await b44.entities.Base.updateMany(
    { id: baseId, manual_reservation_token: expectedToken },
    { $set: { dispatch_status: 'libre', manual_reservation_token: null, manual_expires_at: null, manual_requested_at: null, active_order_id: null } }
  );
  
  if ((bRes.matchedCount ?? bRes.modifiedCount ?? bRes.updated ?? 0) === 1) {
     await safeAuditLog(b44, { action: 'MANUAL_TIMEOUT', user_type: 'sistema', user_name: 'System', details: `Timeout manual expirado para token ${expectedToken}` });
     return { status: 'recovered', baseId, token: expectedToken };
  }
  return { status: 'already_recovered', baseId, token: expectedToken };
}