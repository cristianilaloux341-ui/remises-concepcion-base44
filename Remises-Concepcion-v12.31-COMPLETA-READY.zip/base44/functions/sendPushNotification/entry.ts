import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// ── VAPID helpers (pure Web Crypto, no external libs) ─────────────────────────

const toBase64Url = (buf) => {
  const bytes = new Uint8Array(buf);
  let bin = '';
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
};

const fromBase64Url = (str) => {
  const b64 = str.replace(/-/g, '+').replace(/_/g, '/');
  const bin = atob(b64);
  const buf = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
  return buf.buffer;
};

// Build minimal VAPID JWT (ES256) using SubtleCrypto with proper r,s serialization
async function buildVapidJwt(audience, privateKeyB64, subject) {
  const header = toBase64Url(new TextEncoder().encode(JSON.stringify({ typ: 'JWT', alg: 'ES256' })));
  const now = Math.floor(Date.now() / 1000);
  const payload = toBase64Url(new TextEncoder().encode(JSON.stringify({
    aud: audience,
    exp: now + 12 * 3600,
    sub: subject,
  })));

  const sigInput = `${header}.${payload}`;

  const privateKeyBuf = fromBase64Url(privateKeyB64);
  const cryptoKey = await crypto.subtle.importKey(
    'pkcs8',
    privateKeyBuf,
    { name: 'ECDSA', namedCurve: 'P-256' },
    false,
    ['sign']
  );

  const sigBuf = await crypto.subtle.sign(
    { name: 'ECDSA', hash: 'SHA-256' },
    cryptoKey,
    new TextEncoder().encode(sigInput)
  );

  // ES256 signature: r and s are each 32 bytes, concatenated directly (not ASN.1 encoded)
  // Web Push expects raw concatenation of r || s (64 bytes total)
  const sig = new Uint8Array(sigBuf).slice(0, 64);

  return `${sigInput}.${toBase64Url(sig)}`;
}

// Encrypt the push payload using RFC 8188 / Web Push encryption
async function encryptPayload(plaintext, auth, p256dh) {
  const authBuf = fromBase64Url(auth);
  const p256dhBuf = fromBase64Url(p256dh);

  // Generate ephemeral key pair
  const ephemeral = await crypto.subtle.generateKey(
    { name: 'ECDH', namedCurve: 'P-256' },
    true,
    ['deriveKey', 'deriveBits']
  );

  const ephPubBuf = await crypto.subtle.exportKey('raw', ephemeral.publicKey);

  // Import recipient public key
  const recipientKey = await crypto.subtle.importKey(
    'raw',
    p256dhBuf,
    { name: 'ECDH', namedCurve: 'P-256' },
    false,
    []
  );

  // ECDH shared secret
  const sharedBuf = await crypto.subtle.deriveBits(
    { name: 'ECDH', public: recipientKey },
    ephemeral.privateKey,
    256
  );

  // HKDF — context strings per RFC 8291
  const enc = new TextEncoder();
  const prk = await hkdf(authBuf, new Uint8Array(sharedBuf), enc.encode('Content-Encoding: auth\0'), 32);

  const salt = crypto.getRandomValues(new Uint8Array(16));

  const cek = await hkdf(salt, prk,
    buildContext(enc.encode('aesgcm'), p256dhBuf, ephPubBuf), 16);
  const nonce = await hkdf(salt, prk,
    buildContext(enc.encode('nonce'), p256dhBuf, ephPubBuf), 12);

  const cekKey = await crypto.subtle.importKey('raw', cek, { name: 'AES-GCM' }, false, ['encrypt']);

  // Pad plaintext with 2-byte length prefix (per draft-ietf-webpush-encryption)
  const plaintextBytes = enc.encode(typeof plaintext === 'string' ? plaintext : JSON.stringify(plaintext));
  const padded = new Uint8Array(plaintextBytes.length + 2);
  padded[0] = 0; padded[1] = 0; // no padding
  padded.set(plaintextBytes, 2);

  const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: nonce }, cekKey, padded);

  return { encrypted, salt, ephPubBuf };
}

function buildContext(label, receiverPub, senderPub) {
  const enc = new TextEncoder();
  const peerLen = new Uint8Array(2);
  const rcvLen = new Uint8Array(2);
  new DataView(peerLen.buffer).setUint16(0, receiverPub.byteLength, false);
  new DataView(rcvLen.buffer).setUint16(0, senderPub.byteLength, false);

  const ctx = new Uint8Array(
    label.length + 1 +
    enc.encode('P-256\0').length +
    2 + receiverPub.byteLength +
    2 + senderPub.byteLength
  );
  let offset = 0;
  ctx.set(label, offset); offset += label.length;
  ctx[offset++] = 0; // null terminator
  const p256label = enc.encode('P-256\0');
  ctx.set(p256label, offset); offset += p256label.length;
  ctx.set(peerLen, offset); offset += 2;
  ctx.set(new Uint8Array(receiverPub), offset); offset += receiverPub.byteLength;
  ctx.set(rcvLen, offset); offset += 2;
  ctx.set(new Uint8Array(senderPub), offset);
  return ctx;
}

async function hkdf(salt, ikm, info, length) {
  const saltKey = await crypto.subtle.importKey('raw', salt, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const prkBuf = await crypto.subtle.sign('HMAC', saltKey, ikm);

  const prkKey = await crypto.subtle.importKey('raw', prkBuf, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const infoWithByte = new Uint8Array(info.length + 1);
  infoWithByte.set(info); infoWithByte[info.length] = 1;
  const okm = await crypto.subtle.sign('HMAC', prkKey, infoWithByte);
  return new Uint8Array(okm).slice(0, length);
}

// ── Send a push message to a single subscription ─────────────────────────────
async function sendWebPush(subscription, payload, vapidPublicKey, vapidPrivateKey) {
  const url = new URL(subscription.endpoint);
  const audience = `${url.protocol}//${url.host}`;

  const jwt = await buildVapidJwt(audience, vapidPrivateKey, 'mailto:radiocab@app.com');

  const { encrypted, salt, ephPubBuf } = await encryptPayload(
    payload,
    subscription.keys.auth,
    subscription.keys.p256dh
  );

  const headers = {
    'Authorization': `vapid t=${jwt},k=${vapidPublicKey}`,
    'Content-Encoding': 'aesgcm',
    'Encryption': `salt=${toBase64Url(salt)}`,
    'Crypto-Key': `dh=${toBase64Url(ephPubBuf)}`,
    'Content-Type': 'application/octet-stream',
    'TTL': '60',
    'Urgency': 'high'
  };

  const res = await fetch(subscription.endpoint, {
    method: 'POST',
    headers,
    body: encrypted,
    signal: AbortSignal.timeout(5000),
  });

  return res.status;
}

// ── Entity to store push subscriptions ───────────────────────────────────────
// We store subscriptions on the Driver entity under push_subscriptions field.
// This function is called from the frontend when a driver registers their SW.

let cachedAccessToken: string | null = null;
let cachedAccessTokenExp: number = 0;

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);

  const body = await req.json();
  
  // Interceptar payload de automación de entidad (RideOrder). El workflow nuevo
  // pasa source+data+old_data explícitamente para no depender de argumentos
  // implícitos del motor de workflows.
  const isRideOrderWorkflow = body?.event?.entity_name === "RideOrder" || body?.source === "ride_order_workflow";
  if (isRideOrderWorkflow && body.data) {
    const isStatusChanged = !body.old_data || body.data.status !== body.old_data.status;

    // Otra defensa para v12.27/v12.29: al fallar su reasignación local, esas APK
    // todavía pueden ejecutar un `ofrecido -> pendiente` directo con una copia vieja.
    // Si el móvil que figura en old_data SIGUE poseyendo la reserva exacta, esa
    // escritura es obsoleta y no puede borrar una oferta válida recién asignada.
    const isLegacyOfferedRollback =
      isStatusChanged &&
      body.old_data?.status === 'ofrecido' &&
      body.data.status === 'pendiente';

    if (isLegacyOfferedRollback) {
      const orderId = body.data.id;

      // Pendiente legítimo: rejectRide sólo coloca esta marca DESPUÉS de recorrer
      // autoritativamente toda la zona y confirmar que no queda candidato.
      const serverAuthorizedPending = body.data.processingAction === 'PENDING_AUTHORIZED';
      if (serverAuthorizedPending) {
        await base44.asServiceRole.entities.RideOrder.updateMany(
          { id:orderId, status:'pendiente', processingAction:'PENDING_AUTHORIZED' },
          { $set:{ processingAction:null } }
        ).catch(()=>{});
      } else {
        const ownerDriverId = body.old_data.reserved_driver_id || body.old_data.driver_id;
        const ownerDriver = ownerDriverId
          ? await base44.asServiceRole.entities.Driver.get(ownerDriverId).catch(() => null)
          : null;
        const ownerStillOwnsExactOffer = Boolean(
          ownerDriver &&
          ownerDriver.dispatch_status === 'automatic_pending' &&
          ownerDriver.reserved_order_id === orderId &&
          ownerDriver.reservation_token === body.old_data.reservation_token
        );
        const ownerSafelyFree = Boolean(
          ownerDriver &&
          ownerDriver.status === 'disponible' &&
          (ownerDriver.dispatch_status == null || ownerDriver.dispatch_status === 'normal') &&
          !ownerDriver.reserved_order_id &&
          !ownerDriver.active_order_id &&
          !ownerDriver.active_ride_id
        );

        let ownerReady = ownerStillOwnsExactOffer;
        if (!ownerReady && ownerSafelyFree && ownerDriverId) {
          const reclaimed = await base44.asServiceRole.entities.Driver.updateMany(
            { id:ownerDriverId, status:'disponible', reserved_order_id:null, active_order_id:null, active_ride_id:null },
            { $set:{ dispatch_status:'automatic_pending', reserved_order_id:orderId, reservation_token:body.old_data.reservation_token } }
          ).catch(() => null);
          ownerReady = (reclaimed?.updated ?? reclaimed?.modifiedCount ?? reclaimed?.matchedCount ?? 0) === 1;
        }

        if (ownerReady) {
          const restoreOffer = {
            status:'ofrecido', driver_id:ownerDriverId, reserved_driver_id:ownerDriverId,
            driver_name:body.old_data.driver_name, assigned_base:body.old_data.assigned_base,
            reservation_token:body.old_data.reservation_token,
            manual_reservation_token:body.old_data.manual_reservation_token,
            assigned_at:body.old_data.assigned_at, offerExpiresAt:body.old_data.offerExpiresAt,
            assignment_attempt:body.old_data.assignment_attempt,
            offered_driver_ids:body.old_data.offered_driver_ids,
            processingAction:null, processingOperationKey:null, processingOwnerId:null,
            processingLeaseExpiresAt:null, processingPhase:null
          };
          const restored = await base44.asServiceRole.entities.RideOrder.updateMany(
            {
              id:orderId, status:'pendiente',
              driver_id:body.data.driver_id ?? null,
              reserved_driver_id:body.data.reserved_driver_id ?? null,
              assignment_attempt:body.data.assignment_attempt ?? body.old_data.assignment_attempt
            },
            { $set:restoreOffer }
          ).catch(() => null);

          if ((restored?.updated ?? restored?.modifiedCount ?? restored?.matchedCount ?? 0) === 1) {
            await base44.asServiceRole.entities.AuditLog.create({
              action:'LEGACY_OFFER_TO_PENDING_ROLLBACK_BLOCKED', user_type:'sistema',
              user_name:body.old_data.driver_name || 'Chofer',
              details:`Se cerró Pendientes y se restauró la oferta legacy ${orderId}`,
              metadata:{ orderId, driverId:ownerDriverId, assignmentAttempt:body.old_data.assignment_attempt, driverWasReclaimed:!ownerStillOwnsExactOffer }
            }).catch(()=>{});
            return Response.json({ ok:true, reason:'legacy_offered_rollback_blocked' });
          }

          if (!ownerStillOwnsExactOffer && ownerDriverId) {
            await base44.asServiceRole.entities.Driver.updateMany(
              { id:ownerDriverId, reserved_order_id:orderId, reservation_token:body.old_data.reservation_token },
              { $set:{ dispatch_status:'normal', reserved_order_id:null, reservation_token:null } }
            ).catch(()=>{});
          }
        }
      }
    }

    // Traba definitiva para APK viejos: esos clientes todavía intentan devolver
    // directamente a `pendiente` un viaje que ya fue aceptado. La Central y el
    // cliente cancelan mediante `cancelado`, por lo que sus cancelaciones siguen normales.
    const protectedAcceptedStatuses = new Set(['aceptado', 'en_camino', 'en_viaje']);
    const isDriverRollbackAfterAccept =
      isStatusChanged &&
      body.data.status === 'pendiente' &&
      protectedAcceptedStatuses.has(body.old_data?.status);

    if (isDriverRollbackAfterAccept) {
      const orderId = body.data.id;
      const previousDriverId = body.old_data.driver_id || body.old_data.reserved_driver_id;
      const restoreOrder = {
        status: body.old_data.status,
        driver_id: body.old_data.driver_id || previousDriverId,
        reserved_driver_id: body.old_data.reserved_driver_id || previousDriverId,
        driver_name: body.old_data.driver_name,
        reservation_token: body.old_data.reservation_token,
        manual_reservation_token: body.old_data.manual_reservation_token,
        offerExpiresAt: body.old_data.offerExpiresAt
      };

      // CAS: solamente se revierte si la orden continúa en el estado ilegal que
      // produjo el móvil. Si la Central ya actuó, no se pisa su decisión.
      await base44.asServiceRole.entities.RideOrder.updateMany(
        { id: orderId, status: 'pendiente', driver_id: body.data.driver_id ?? null },
        { $set: restoreOrder }
      );

      // Los APK viejos liberan el registro Driver inmediatamente después. Esperamos
      // ese segundo paso y restauramos el vínculo con el viaje aceptado.
      if (previousDriverId) {
        await new Promise(resolve => setTimeout(resolve, 750));
        await base44.asServiceRole.entities.Driver.updateMany(
          {
            id: previousDriverId,
            $or: [
              { active_ride_id: null },
              { active_ride_id: orderId },
              { active_ride_id: { $exists: false } }
            ]
          },
          { $set: {
            status: 'en_viaje',
            dispatch_status: 'normal',
            active_ride_id: orderId,
            reserved_order_id: orderId
          } }
        );
      }

      await base44.asServiceRole.entities.AuditLog.create({
        action: 'CANCELACION_CHOFER_BLOQUEADA',
        user_type: 'sistema',
        user_name: body.old_data.driver_name || 'Chofer',
        details: `Se bloqueó la anulación posterior a la aceptación del viaje ${orderId}`,
        metadata: { orderId, driverId: previousDriverId, previousStatus: body.old_data.status }
      }).catch(() => {});

      return Response.json({ ok: true, reason: 'driver_cancel_after_accept_blocked' });
    }
    
    const targetDriverId = body.data.driver_id || body.data.reserved_driver_id || body.data.preassigned_driver_id;
    const oldTargetDriverId = body.old_data
      ? (body.old_data.driver_id || body.old_data.reserved_driver_id || body.old_data.preassigned_driver_id)
      : null;

    // Las ofertas `ofrecido` se envían exclusivamente por el camino directo del
    // despacho (DispatchLogic / rechazo / timeout). Si la automatización también
    // las enviara, el mismo assignment_attempt podría generar dos FCM y dos avisos
    // en el teléfono. La automatización se conserva para aceptación, cancelación,
    // vuelta a pendiente y las protecciones de compatibilidad de APK viejos.
    if (body.data.status === "ofrecido" && targetDriverId && isStatusChanged) {
      return Response.json({ ok: true, reason: 'offer_push_handled_by_direct_dispatch' });
    } else if (isStatusChanged && (body.data.status === "aceptado" || body.data.status === "cancelado" || body.data.status === "pendiente")) {
      body.action = "cancel_multiple";
      body.orderId = body.data.id;
      
      let toCancel = [];
      
      if (body.data.status === "cancelado") {
        // Si era un próximo viaje, liberar únicamente esa preasignación.
        // Nunca modificar active_order_id, active_ride_id ni el viaje/taxímetro actual.
        const nextDriverId = body.old_data?.preassigned_driver_id || body.data.preassigned_driver_id;
        const nextToken = body.old_data?.preassignment_token || body.data.preassignment_token;
        if (nextDriverId) {
          const releaseQuery: any = { id: nextDriverId, next_order_id: body.data.id };
          if (nextToken) releaseQuery.next_order_token = nextToken;
          await base44.asServiceRole.entities.Driver.updateMany(
            releaseQuery,
            { $set: { next_order_id: null, next_order_token: null } }
          ).catch(error => console.error("No se pudo liberar próximo viaje cancelado", error));
        }

        // Cancelación: la fuente de verdad es la relación activa inmediatamente ANTES de cancelar.
        // Así aseguramos que si el operador cancela y limpia el driver_id al mismo tiempo,
        // el móvil que tenía el viaje reciba la alerta para apagarse.
        const recipient = oldTargetDriverId || targetDriverId;
        if (recipient) {
          toCancel.push(recipient);
        }
      } else {
        // Para pendiente (rechazo/timeout), silenciamos al oldTargetDriverId.
        if (oldTargetDriverId) toCancel.push(oldTargetDriverId);
        
        if (body.data.status === "aceptado" && targetDriverId) {
          // Al ganar un móvil, cerrar visualmente ESA orden en todos los móviles
          // que la recibieron en intentos anteriores. offered_driver_ids se usa
          // sólo como historial de destinatarios del push: NO libera estados,
          // NO toca cola y NO modifica otros viajes de esos choferes.
          const historicalRecipients = [
            ...(Array.isArray(body.old_data?.offered_driver_ids) ? body.old_data.offered_driver_ids : []),
            ...(Array.isArray(body.data?.offered_driver_ids) ? body.data.offered_driver_ids : [])
          ];
          for (const historicalDriverId of historicalRecipients) {
            if (historicalDriverId && historicalDriverId !== targetDriverId) toCancel.push(historicalDriverId);
          }
          toCancel = toCancel.filter(id => id !== targetDriverId);
        }
      }
      
      body.driversToCancel = [...new Set(toCancel)];
    }
    
    // Si la automatización se disparó pero no cambió el estado a algo relevante, abortar limpiamente
    if (!body.action) {
      return Response.json({ ok: true, reason: 'ignored_by_automation' });
    }
  }

  // Interceptar payload de automación de RideOrder para Cliente (Viaje Iniciado)
  if (body.event && body.event.entity_name === "RideOrder" && body.data) {
    const isStatusChanged = !body.old_data || body.data.status !== body.old_data.status;
    if (isStatusChanged && body.data.status === "en_viaje" && body.data.client_id) {
       // El chofer indica que el viaje ha iniciado
       body.action = "send_client_push";
       body.payloadType = "viaje_iniciado";
       body.userId = body.data.client_id;
       body.orderId = body.data.id;
    }
  }

  const { action, driverId, subscription, orderId, orderData, userId, fromName, messageContent, driversToCancel, payloadType, internalKey, sessionToken } = body;

  // Validación de seguridad estricta para notificaciones y suscripciones
  const isPublicAction = ['vapid_public_key'].includes(action);
  const { verifyRequestAuth } = await import('../../shared/security.ts');
  
  let isAuthorized = false;
  if (isPublicAction) {
    isAuthorized = true; 
  } else if (body.internalKey && body.internalKey === Deno.env.get("INTERNAL_SERVICE_KEY")) {
    isAuthorized = true;
  } else if (body.event && body.event.entity_name) {
    // Las automatizaciones de Base44 son confiables
    isAuthorized = true;
  } else {
    if (['subscribe_fcm', 'subscribe'].includes(action)) {
      isAuthorized = await verifyRequestAuth(base44.asServiceRole, body, { allowDriverId: driverId });
    } else if (action === 'subscribe_operator') {
      isAuthorized = await verifyRequestAuth(base44.asServiceRole, body, { allowOperator: true });
    } else {
      // Intentamos con token de operador
      isAuthorized = await verifyRequestAuth(base44.asServiceRole, body, { allowOperator: true });
    }
  }

  if (!isAuthorized) {
    return Response.json({ error: 'unauthorized', reason: 'Missing or invalid security key' }, { status: 401 });
  }

  const VAPID_PUBLIC_KEY = Deno.env.get('VAPID_PUBLIC_KEY');
  const VAPID_PRIVATE_KEY = Deno.env.get('VAPID_PRIVATE_KEY');

  // ── Register subscription ─────────────────────────────────────────────────
  if (action === 'subscribe_fcm') {
    if (!driverId || !body.token) return Response.json({ error: 'Missing driverId or token' }, { status: 400 });
    await base44.asServiceRole.entities.Driver.update(driverId, { fcm_token: body.token });
    return Response.json({ ok: true });
  }

  if (action === 'subscribe') {
    if (!driverId || !subscription) return Response.json({ error: 'Missing driverId or subscription' }, { status: 400 });
    await base44.asServiceRole.entities.Driver.update(driverId, { push_subscription: JSON.stringify(subscription) });
    return Response.json({ ok: true });
  }

  if (action === 'subscribe_operator') {
    if (!userId || !subscription) return Response.json({ error: 'Missing userId or subscription' }, { status: 400 });
    await base44.asServiceRole.entities.User.update(userId, { push_subscription: JSON.stringify(subscription) });
    return Response.json({ ok: true });
  }

  if (action === 'send_to_operators') {
    if (!VAPID_PUBLIC_KEY || !VAPID_PRIVATE_KEY) return Response.json({ error: 'VAPID keys not configured' }, { status: 500 });
    try {
      const users = await base44.asServiceRole.entities.User.filter({ role: 'admin' });
      const results = [];
      for (const u of users) {
        if (!u.push_subscription) continue;
        let sub;
        try { sub = JSON.parse(u.push_subscription); } catch (_) { continue; }
        const payload = JSON.stringify({
          type: 'NEW_MESSAGE',
          title: `📩 Mensaje de ${fromName || 'Móvil'}`,
          body: messageContent || 'Nuevo mensaje en el chat',
          url: '/messages',
          tag: 'msg-' + Date.now(),
        });
        const status = await sendWebPush(sub, payload, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);
        if (status === 410 || status === 404) await base44.asServiceRole.entities.User.update(u.id, { push_subscription: null });
        results.push({ userId: u.id, status });
      }
      return Response.json({ ok: true, results });
    } catch (err) {
      return Response.json({ ok: false, error: err.message }, { status: 500 });
    }
  }

  if (action === 'cancel_multiple' || action === 'cancel_ride') {
    const listToCancel = driversToCancel || (driverId ? [driverId] : []);
    if (!listToCancel || listToCancel.length === 0 || !orderId) return Response.json({ ok: true, reason: 'no_drivers_to_cancel' });
    try {
      const saStr = Deno.env.get('FIREBASE_SERVICE_ACCOUNT');
      let tokenRes = null;
      let sa = null;

      if (saStr) {
         try {
           sa = JSON.parse(saStr);
           const now = Math.floor(Date.now() / 1000);
           if (!cachedAccessToken || now >= cachedAccessTokenExp) {
             const jwtHeader = toBase64Url(new TextEncoder().encode(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
             const jwtPayload = toBase64Url(new TextEncoder().encode(JSON.stringify({
               iss: sa.client_email, scope: 'https://www.googleapis.com/auth/firebase.messaging', aud: 'https://oauth2.googleapis.com/token', exp: now + 3600, iat: now
             })));
             const pemContents = sa.private_key.replace("-----BEGIN PRIVATE KEY-----", "").replace("-----END PRIVATE KEY-----", "").replace(/\s/g, "");
             const binaryDer = Uint8Array.from(atob(pemContents), c => c.charCodeAt(0));
             const rsaKey = await crypto.subtle.importKey("pkcs8", binaryDer, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
             const signature = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", rsaKey, new TextEncoder().encode(`${jwtHeader}.${jwtPayload}`));
             const jwt = `${jwtHeader}.${jwtPayload}.${toBase64Url(signature)}`;
             tokenRes = await fetch('https://oauth2.googleapis.com/token', {
               method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
               body: `grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=${jwt}`,
               signal: AbortSignal.timeout(5000)
             }).then(r => r.json());
             if (tokenRes.access_token) {
               cachedAccessToken = tokenRes.access_token;
               cachedAccessTokenExp = now + 3500;
             }
           }
         } catch(e) {
           console.error("Token fetch error cancel_multiple", e);
         }
      }

      const currentOrder = await base44.asServiceRole.entities.RideOrder.get(orderId).catch(() => null);
      // En rechazo/timeout el RideOrder puede haber avanzado YA al intento siguiente.
      // La cancelación debe apuntar al intento que tenía el teléfono anterior,
      // no al assignment_attempt actual del pasaje.
      const currentAttempt = Number(orderData?.assignmentAttempt ?? currentOrder?.assignment_attempt ?? 1);
      
      for (const dId of listToCancel) {
        const drivers = await base44.asServiceRole.entities.Driver.filter({ id: dId });
        const driver = drivers[0];
        if (!driver) continue;

        // IMPORTANTE: enviar/cancelar una notificación NUNCA modifica la cola.
        // `cancel_multiple` puede incluir móviles que recibieron la oferta en intentos
        // anteriores; tocar queue_entered_at acá desordena posiciones sin una orden
        // operativa real. La liberación/reubicación de un móvil pertenece al flujo
        // atómico de reject/timeout/cancel correspondiente, no al transporte push.

        // Native FCM Cancel (Prioritize over Web Push)
        if (driver.fcm_token && cachedAccessToken) {
           try {
             const fcmRes = await fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
               method: 'POST', headers: { 'Authorization': `Bearer ${cachedAccessToken}`, 'Content-Type': 'application/json' },
               signal: AbortSignal.timeout(5000),
               body: JSON.stringify({
                 message: {
                   token: driver.fcm_token,
                   data: {
                     type: "cancelar",
                     // Mantener el ID real del viaje. El intento viaja separado.
                     // Así la APK actual crea y cancela EXACTAMENTE la misma alerta
                     // sin depender de sufijos _att_N para apagar sonido/burbuja.
                     orderId: String(orderId),
                     assignmentAttempt: String(currentAttempt),
                     sentAt: Date.now().toString()
                   },
                   android: {
                     priority: "HIGH",
                     ttl: "30s",
                     collapse_key: `ride_${orderId}_${dId}`
                   }
                 }
               })
             });
             if (!fcmRes.ok) {
               const errText = await fcmRes.text();
               console.error("FCM Cancel Error:", errText);
               if (errText.includes("UNREGISTERED") || errText.includes("NOT_FOUND") || fcmRes.status === 404) {
                 await base44.asServiceRole.entities.Driver.update(driver.id, { fcm_token: null });
               }
             } else {
               console.log("FCM Cancel Success sent to", driver.id);

               // Segunda señal sólo para la WebView ya instalada: no crea una alerta
               // nativa nueva. Fuerza a releer el RideOrder; si ya pasó a otro móvil,
               // la plantilla vieja se descarta como lo hace el propio Rechazar.
               const syncRes = await fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
                 method: 'POST',
                 headers: { 'Authorization': `Bearer ${cachedAccessToken}`, 'Content-Type': 'application/json' },
                 signal: AbortSignal.timeout(5000),
                 body: JSON.stringify({
                   message: {
                     token: driver.fcm_token,
                     data: {
                       type: "sync_after_cancel",
                       orderId: String(orderId),
                       assignmentAttempt: String(currentAttempt),
                       sentAt: Date.now().toString()
                     },
                     android: { priority: "HIGH", ttl: "30s" }
                   }
                 })
               }).catch(() => null);

               await base44.asServiceRole.entities.AuditLog.create({
                 action: "cancel_push_enviado",
                 user_type: "sistema",
                 user_name: "Sistema",
                 details: `FCM de cierre enviado a ${driver.name || driver.id}`,
                 metadata: { orderId, driverId: driver.id, assignmentAttempt: currentAttempt, orderIdFormat: "base", syncSent: !!syncRes?.ok }
               }).catch(() => {});
             }
           } catch(e) {
               console.error("FCM Cancel Exception:", e);
           }
        }
        // Fallback to Web Push
        else if (driver.push_subscription && VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY) {
          try {
            const sub = JSON.parse(driver.push_subscription);
            const payload = JSON.stringify({
              type: 'RIDE_CANCELLED',
              orderId,
              title: '❌ Viaje ya no disponible',
              body: 'El viaje fue asignado a otro móvil o cancelado.'
            });
            const status = await sendWebPush(sub, payload, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);
            if (status === 410 || status === 404) await base44.asServiceRole.entities.Driver.update(driver.id, { push_subscription: null });
          } catch(e) {}
        }
        
        // Limpieza de bloque obsoleto
      }

      return Response.json({ ok: true });
    } catch (err) {
      return Response.json({ ok: false, error: err.message });
    }
  }

  if (action === 'send_client_alert' || action === 'send_client_push') {
    if (!userId) return Response.json({ error: 'Missing userId' }, { status: 400 });
    try {
      const users = await base44.asServiceRole.entities.User.filter({ id: userId });
      const user = users[0];
      if (!user) return Response.json({ error: 'User not found' }, { status: 404 });
      
      const saStr = Deno.env.get('FIREBASE_SERVICE_ACCOUNT');
      let fcmSuccess = false;
      
      if (user.fcm_token && saStr) {
         const sa = JSON.parse(saStr);
         const now = Math.floor(Date.now() / 1000);
         if (!cachedAccessToken || now >= cachedAccessTokenExp) {
           const jwtHeader = toBase64Url(new TextEncoder().encode(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
           const jwtPayload = toBase64Url(new TextEncoder().encode(JSON.stringify({
             iss: sa.client_email, scope: 'https://www.googleapis.com/auth/firebase.messaging', aud: 'https://oauth2.googleapis.com/token', exp: now + 3600, iat: now
           })));
           const pemContents = sa.private_key.replace("-----BEGIN PRIVATE KEY-----", "").replace("-----END PRIVATE KEY-----", "").replace(/\s/g, "");
           const binaryDer = Uint8Array.from(atob(pemContents), c => c.charCodeAt(0));
           const rsaKey = await crypto.subtle.importKey("pkcs8", binaryDer, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
           const signature = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", rsaKey, new TextEncoder().encode(`${jwtHeader}.${jwtPayload}`));
           const jwt = `${jwtHeader}.${jwtPayload}.${toBase64Url(signature)}`;
           const tokenRes = await fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, signal: AbortSignal.timeout(5000), body: `grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=${jwt}` }).then(r => r.json());
           if (tokenRes.access_token) { cachedAccessToken = tokenRes.access_token; cachedAccessTokenExp = now + 3500; }
         }
         
         if (cachedAccessToken) {
           const fcmPayload = {
             message: {
               token: user.fcm_token,
               data: { type: payloadType || "bocina", orderId: String(orderId || "") },
               android: { priority: "HIGH" }
             }
           };
           const fcmRes = await fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
             method: 'POST', headers: { 'Authorization': `Bearer ${cachedAccessToken}`, 'Content-Type': 'application/json' },
             body: JSON.stringify(fcmPayload),
             signal: AbortSignal.timeout(5000)
           });
           if (!fcmRes.ok) {
             const errText = await fcmRes.text();
             if (errText.includes("UNREGISTERED") || errText.includes("NOT_FOUND") || fcmRes.status === 404) {
               await base44.asServiceRole.entities.User.update(user.id, { fcm_token: null });
             }
           } else {
             fcmSuccess = true;
           }
         }
      }
      return Response.json({ ok: fcmSuccess });
    } catch (err) {
      return Response.json({ ok: false, error: err.message });
    }
  }

  if (action === 'send') {
    if (!driverId || !orderId) {
      return Response.json({ error: 'Missing driverId or orderId' }, { status: 400 });
    }

    try {
      const drivers = await base44.asServiceRole.entities.Driver.filter({ id: driverId });
      const driver = drivers[0];

      // Última barrera antes de FCM/WebPush. Aunque una ruta vieja o una carrera
      // intente notificar, no despertar un teléfono fuera de servicio, sin base o
      // que ya no conserve la reserva de ESTA orden.
      const cleanOrderId = String(orderId).split('_att_')[0];
      if (
        !driver ||
        driver.status !== 'disponible' ||
        !driver.current_base ||
        String(driver.reserved_order_id || '') !== cleanOrderId
      ) {
        return Response.json({
          ok: false,
          reason: 'driver_not_eligible_at_push_time',
          driverStatus: driver?.status ?? null,
          currentBase: driver?.current_base ?? null
        });
      }
      
      const title = '🚖 ¡NUEVO VIAJE!';
      let bodyStr = orderData ? `${orderData.pickup_address}${orderData.dropoff_address ? ' → ' + orderData.dropoff_address : ''}${orderData.fare ? ' · $' + orderData.fare : ''}` : 'Tenés un viaje asignado';
      if (orderData && orderData.notes) {
        bodyStr += `\n📌 Notas: ${orderData.notes}`;
      }

      let webPushStatus = null;
      let webPushSuccess = false;
      let fcmSuccess = false;

      // Intentar enviar por FCM nativo si el chofer tiene el token (Prioridad)
      if (driver.fcm_token) {
         try {
           // Generar URL pública asegurada para que el teléfono pueda hacer el POST de respuesta
           const appId = Deno.env.get("BASE44_APP_ID") || req.headers.get("x-base44-app-id") || "6a1fcdd119031a7db72f3840";
           const apiUrl = `https://base44.app/api/apps/${appId}/functions/invoke/handleNativePushAction`;
           const saStr = Deno.env.get('FIREBASE_SERVICE_ACCOUNT');
           if (saStr) {
             const sa = JSON.parse(saStr);
             const now = Math.floor(Date.now() / 1000);
             
             if (!cachedAccessToken || now >= cachedAccessTokenExp) {
               const jwtHeader = toBase64Url(new TextEncoder().encode(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
               const jwtPayload = toBase64Url(new TextEncoder().encode(JSON.stringify({
                 iss: sa.client_email,
                 scope: 'https://www.googleapis.com/auth/firebase.messaging',
                 aud: 'https://oauth2.googleapis.com/token',
                 exp: now + 3600,
                 iat: now
               })));
               const pemContents = sa.private_key.replace("-----BEGIN PRIVATE KEY-----", "").replace("-----END PRIVATE KEY-----", "").replace(/\s/g, "");
               const binaryDer = Uint8Array.from(atob(pemContents), c => c.charCodeAt(0));
               const rsaKey = await crypto.subtle.importKey(
                 "pkcs8", binaryDer, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]
               );
               const signature = await crypto.subtle.sign(
                 "RSASSA-PKCS1-v1_5", rsaKey, new TextEncoder().encode(`${jwtHeader}.${jwtPayload}`)
               );
               const jwt = `${jwtHeader}.${jwtPayload}.${toBase64Url(signature)}`;
               const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
                 method: 'POST',
                 headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                 body: `grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=${jwt}`,
                 signal: AbortSignal.timeout(5000)
               }).then(r => r.json());
               
               if (tokenRes.access_token) {
                 cachedAccessToken = tokenRes.access_token;
                 cachedAccessTokenExp = now + 3500;
               }
             }
             
             if (cachedAccessToken) {
               const fcmPayload = {
                 message: {
                   token: driver.fcm_token,
                   data: {
                     type: "ofrecido",
                     // El ID del viaje se mantiene estable. assignmentAttempt lleva
                     // la versión de la oferta por separado y ya es leída por las APK.
                     orderId: String(orderId),
                     driverId: String(driverId),
                     driverName: String(driver.name || ""),
                     base: String(driver.current_base || ""),
                     apiUrl: String(apiUrl),
                     title: String(title),
                     body: String(bodyStr),
                     sentAt: Date.now().toString(),
                     assignmentAttempt: orderData?.assignmentAttempt?.toString() || "1",
                     orderNotes: String(orderData?.notes || "")
                   },
                   android: {
                     priority: "HIGH",
                     ttl: "60s",
                     collapse_key: `ride_${orderId}_${driverId}`
                   }
                 }
               };
               console.log("Enviando FCM Payload:", JSON.stringify(fcmPayload));
               
               const fcmRes = await fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
                 method: 'POST',
                 headers: {
                   'Authorization': `Bearer ${cachedAccessToken}`,
                   'Content-Type': 'application/json'
                 },
                 body: JSON.stringify(fcmPayload),
                 signal: AbortSignal.timeout(5000)
               });
               if (!fcmRes.ok) {
                 const errText = await fcmRes.text();
                 console.error("FCM Send Error HTTP " + fcmRes.status + ":", errText);
                 
                 // If the token is no longer valid, clear it so we don't keep trying and failing silently
                 if (errText.includes("UNREGISTERED") || errText.includes("NOT_FOUND") || fcmRes.status === 404) {
                   await base44.asServiceRole.entities.Driver.update(driverId, { fcm_token: null });
                   console.log("FCM Token cleared for driver", driverId, "due to UNREGISTERED/NOT_FOUND");
                 }
                 
                 // No retornamos error aquí, permitimos que intente el fallback de WebPush
                 fcmSuccess = false;
               } else {
                 const successBody = await fcmRes.text();
                 console.log("FCM Send Success:", successBody);
                 fcmSuccess = true;
                 
                 if (fcmPayload.message.data.type === "ofrecido") {
                   base44.asServiceRole.entities.AuditLog.create({
                     action: "push_enviado",
                     user_type: "sistema",
                     user_name: "Sistema",
                     details: `FCM push enviado a la cola nativa de Google para ${driver.name || driverId}`,
                     metadata: { orderId: orderId.toString().split('_att_')[0], driverId }
                   }).catch(() => {});
                 }
               }
             } else {
               console.error("FCM Send Error: No se pudo obtener cachedAccessToken");
             }
           } else {
             console.error("FCM Send Error: Falta FIREBASE_SERVICE_ACCOUNT");
           }
         } catch(e) {
           console.error("Excepción en FCM Nativo:", e);
         }
      } 
      // Fallback a Web Push si no tiene FCM o si falló el envío por FCM
      if (!fcmSuccess && driver?.push_subscription && VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY) {
        try {
          let sub = JSON.parse(driver.push_subscription);
          const payload = JSON.stringify({
            type: 'NEW_RIDE',
            orderId,
            driverId,
            title,
            body: bodyStr,
            actions: [
              { action: 'accept', title: '✅ Aceptar' },
              { action: 'reject', title: '❌ Rechazar' }
            ]
          });
          webPushStatus = await sendWebPush(sub, payload, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);
          if (webPushStatus === 410 || webPushStatus === 404) {
            await base44.asServiceRole.entities.Driver.update(driverId, { push_subscription: null });
          }
          webPushSuccess = webPushStatus >= 200 && webPushStatus < 300;
          
          if (webPushSuccess && title === '🚖 ¡NUEVO VIAJE!') {
            base44.asServiceRole.entities.AuditLog.create({
              action: "push_enviado",
              user_type: "sistema",
              user_name: "Sistema",
              details: `Web Push alternativo enviado para ${driver.name || driverId}`,
              metadata: { orderId: orderId.toString().split('_att_')[0], driverId }
            }).catch(() => {});
          }
        } catch (_) {}
      }

      const success = webPushSuccess || fcmSuccess;
      return Response.json({ ok: success, status: webPushStatus });
    } catch (err) {
      return Response.json({ ok: false, reason: 'send_error', error: err.message });
    }
  }

  if (action === 'vapid_public_key') {
    return Response.json({ publicKey: VAPID_PUBLIC_KEY });
  }

  return Response.json({ error: 'Unknown action' }, { status: 400 });
});