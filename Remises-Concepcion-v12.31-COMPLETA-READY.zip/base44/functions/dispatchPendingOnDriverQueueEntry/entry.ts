import { createClientFromRequest } from 'npm:@base44/sdk@0.8.48';
import { findNextDriverInZone } from '../../shared/driverSelection.ts';
import { getNextQueueTailAt, getNextQueuePosition, compactQueue, compactQueueUnlocked, withQueueLock } from '../../shared/queueOrder.ts';
import { verifyReorderToken } from '../../shared/reorderToken.ts';

const CENTRAL_REVIEW_MARKER = '[REVISION_CENTRAL_CANCELADO_CHOFER]';
const PROTECTED_ACTIONS = new Set(['ACCEPT', 'START', 'FINISH']);

// Defensa para APK instaladas que todavía contienen lógica vieja de limpieza local.
// Si un Driver pierde su reserva mientras el RideOrder sigue `ofrecido`, restauramos
// el vínculo desde la autoridad server-side. Si la oferta ya venció, la cerramos de
// forma CAS. Así nunca queda el estado partido Driver libre / RideOrder ofrecido.
async function guardOfferedReservationIntegrity(b44:any, driverId:string) {
  const driver = await b44.entities.Driver.get(driverId).catch(() => null);
  if (!driver) return { repaired:false, reason:'DRIVER_NOT_FOUND' };

  const offers = await b44.entities.RideOrder.filter({
    reserved_driver_id: driverId,
    status: 'ofrecido'
  }).catch(() => []);
  if (!offers.length) return { repaired:false, reason:'NO_ACTIVE_OFFER' };

  const exact = offers.find((o:any) =>
    driver.dispatch_status === 'automatic_pending' &&
    driver.reserved_order_id === o.id &&
    driver.reservation_token === o.reservation_token
  );
  if (exact) return { repaired:false, reason:'ALREADY_CONSISTENT' };

  const order = [...offers].sort((a:any,b:any) =>
    new Date(b.assigned_at || b.updated_date || 0).getTime() - new Date(a.assigned_at || a.updated_date || 0).getTime()
  )[0];
  const now = Date.now();
  const expiresAt = Number(order.offerExpiresAt);
  const expired = Number.isFinite(expiresAt) && expiresAt <= now;
  const driverBusyElsewhere =
    driver.status === 'en_viaje' ||
    Boolean(driver.active_order_id) ||
    Boolean(driver.active_ride_id) ||
    Boolean(driver.reserved_order_id && driver.reserved_order_id !== order.id);

  // Si la oferta venció y el móvil simplemente perdió su vínculo local (caso
  // compatible con v12.27), NO mandarla directo a Pendiente: eso salteaba el
  // motor único rejectRide y podía omitir al siguiente móvil válido de la zona.
  // Restauramos primero la reserva exacta por CAS y dejamos que rejectRide procese
  // el timeout, con su selección FIFO, nuevo attempt/token y exclusiones.
  if (expired && !driverBusyElsewhere) {
    const restoredForTimeout = await b44.entities.Driver.updateMany(
      {
        id: driverId,
        status: driver.status,
        dispatch_status: driver.dispatch_status,
        reserved_order_id: driver.reserved_order_id ?? null,
        active_order_id: driver.active_order_id ?? null,
        active_ride_id: driver.active_ride_id ?? null,
        reservation_token: driver.reservation_token ?? null
      },
      { $set: {
        status:'disponible',
        dispatch_status:'automatic_pending',
        reserved_order_id:order.id,
        reservation_token:order.reservation_token,
        active_order_id:null,
        active_ride_id:null,
        current_base:order.assigned_base || driver.current_base
      } }
    ).catch(() => ({ updated:0 }));
    const restoredCount = restoredForTimeout?.updated ?? restoredForTimeout?.matchedCount ?? restoredForTimeout?.modifiedCount ?? 0;
    if (restoredCount !== 1) return { repaired:false, reason:'CONCURRENT_CHANGE' };

    const timeoutRes = await b44.functions.invoke('rejectRide', {
      orderId:order.id,
      driverId,
      assignmentAttempt:Number(order.assignment_attempt || 1),
      source:'timeout',
      internalKey:Deno.env.get('INTERNAL_SERVICE_KEY')
    }).catch((error:any) => ({ data:{ success:false, reason:error?.message || 'INVOKE_FAILED' } }));
    const timeoutData = timeoutRes?.data || timeoutRes;
    await b44.entities.AuditLog.create({
      action:'ORPHAN_EXPIRED_OFFER_ROUTED_TO_REJECT_ENGINE',
      user_type:'sistema',
      user_name:'DriverStateGuard',
      details:`Oferta vencida ${order.id} enviada al motor único de timeout/reasignación`,
      metadata:{ orderId:order.id, driverId, assignmentAttempt:order.assignment_attempt, timeoutResult:timeoutData?.reason || null }
    }).catch(()=>{});
    return { repaired:true, action:'EXPIRED_OFFER_ROUTED_TO_REJECT_ENGINE', timeoutResult:timeoutData };
  }

  if (driverBusyElsewhere) {
    // Un Driver ocupado con otro viaje es una inconsistencia, no autorización para
    // abrir Pendientes. No tocamos el RideOrder ofrecido: el timeout/reconciliador
    // autoritativo lo cerrará y recorrerá la cola. Esto evita cortar A→B→C por un
    // vínculo roto o una carrera del APK legacy.
    await b44.entities.AuditLog.create({
      action:'ORPHAN_OFFER_DRIVER_BUSY_FAIL_CLOSED', user_type:'sistema', user_name:'DriverStateGuard',
      details:`Oferta ${order.id} conservada al detectar ${driverId} ocupado en otro viaje; Pendientes bloqueado`,
      metadata:{ orderId:order.id, driverId, expired, driverBusyElsewhere }
    }).catch(()=>{});
    return { repaired:false, reason:'DRIVER_BUSY_FAIL_CLOSED' };
  }

  // Oferta todavía vigente y móvil sin otro viaje: el RideOrder es la autoridad.
  // Restauramos exactamente su orderId/token. El filtro usa el snapshot fresco del
  // Driver, por lo que una asignación/aceptación concurrente hace fallar el CAS.
  const restored = await b44.entities.Driver.updateMany(
    {
      id: driverId,
      status: driver.status,
      dispatch_status: driver.dispatch_status,
      reserved_order_id: driver.reserved_order_id ?? null,
      active_order_id: driver.active_order_id ?? null,
      active_ride_id: driver.active_ride_id ?? null,
      reservation_token: driver.reservation_token ?? null
    },
    { $set: {
      status:'disponible',
      dispatch_status:'automatic_pending',
      reserved_order_id:order.id,
      active_order_id:null,
      active_ride_id:null,
      reservation_token:order.reservation_token,
      manual_reservation_token:null,
      current_base:order.assigned_base || driver.current_base
    } }
  ).catch(() => ({ updated:0 }));
  if ((restored.updated ?? restored.matchedCount ?? restored.modifiedCount ?? 0) === 1) {
    await b44.entities.AuditLog.create({
      action:'DRIVER_OFFER_LINK_RESTORED', user_type:'sistema', user_name:'DriverStateGuard',
      details:`Restaurado vínculo del móvil ${driverId} con oferta vigente ${order.id}`,
      metadata:{ orderId:order.id, driverId, assignmentAttempt:order.assignment_attempt }
    }).catch(() => {});
    return { repaired:true, action:'DRIVER_RESERVATION_RESTORED' };
  }
  return { repaired:false, reason:'CONCURRENT_CHANGE' };
}

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const b44 = base44.asServiceRole;

  const placeDriverLastLocked = async (
    baseName:string,
    targetDriverId:string,
    filter:any,
    extraSet:any = {}
  ) => withQueueLock(b44, baseName, async () => {
    const queueAt = await getNextQueueTailAt(b44, baseName, targetDriverId);
    const nextPos = await getNextQueuePosition(b44, baseName, targetDriverId);
    const result = await b44.entities.Driver.updateMany(
      filter,
      { $set:{
        ...extraSet,
        queue_entered_at:queueAt,
        queue_authoritative_base:baseName,
        queue_authoritative_at:queueAt,
        queue_position:nextPos,
        queue_authority_marker:nextPos,
        queue_left_at:null
      } }
    ).catch(()=>({updated:0}));
    const count = result?.updated ?? result?.modifiedCount ?? result?.matchedCount ?? 0;
    if (count === 1) await compactQueueUnlocked(b44, baseName);
    return { result, count, queueAt, nextPos };
  });

  try {
    const body = await req.json().catch(() => ({}));
    const eventData = body?.data || null;
    const oldData = body?.old_data || null;
    const directDriverId = body?.driverId || null;

    // Esta función está pensada para el workflow de Driver. También acepta
    // driverId directo para poder verificarla de forma controlada sin duplicar lógica.
    if (body?.event && body.event.entity_name !== 'Driver') {
      return Response.json({ success: true, skipped: true, reason: 'NOT_DRIVER_EVENT' });
    }

    const driverId = eventData?.id || directDriverId;
    if (!driverId) {
      return Response.json({ success: true, skipped: true, reason: 'MISSING_DRIVER_ID' });
    }

    // CORTE DE CONSUMO: este workflow recibe también heartbeats/GPS de todos los
    // móviles. Si no cambió ningún campo operativo de cola/oferta, salir ANTES de
    // hacer Driver.get, consultas de RideOrder o reconciliaciones. Con ~50 móviles
    // evita que cada latido dispare trabajo de despacho innecesario.
    if (eventData && oldData) {
      const operationalFields = [
        'status', 'dispatch_status', 'current_base', 'queue_entered_at',
        'queue_position', 'queue_authoritative_base', 'queue_authoritative_at',
        'queue_authority_marker', 'reserved_order_id', 'reservation_token',
        'active_order_id', 'active_ride_id'
      ];
      const operationalChange = operationalFields.some((field) =>
        String(eventData?.[field] ?? '') !== String(oldData?.[field] ?? '')
      );
      if (!operationalChange) {
        return Response.json({ success:true, skipped:true, reason:'NON_OPERATIONAL_DRIVER_UPDATE' });
      }
    }

    // REGLA OPERATIVA DE SALIDA/ENTRADA DE BASE:
    // una salida REAL (fuera de servicio, viaje, cambio de base o acción comercial)
    // pierde la posición inmediatamente. Pero las APK v12.27/v12.29 publican a veces
    // un current_base=null técnico de pocos segundos mientras siguen DISPONIBLES,
    // sin viaje, sin rechazo y sin cambio real de estado. Ese null técnico NO es una
    // salida de cola y debe revertirse server-side para no mover al móvil solo.

    // Marca una entrada NUEVA que ya fue normalizada con hora autoritativa del servidor.
    // Debe seguir hasta el drenaje de Pendientes; una entrada real crea capacidad.
    let normalizedExplicitQueueEntry = false;

    const technicalBaseDrop = Boolean(
      eventData && oldData &&
      oldData.status === 'disponible' &&
      eventData.status === 'disponible' &&
      oldData.current_base &&
      !eventData.current_base &&
      oldData.queue_authoritative_base === oldData.current_base &&
      Number.isFinite(Number(oldData.queue_position)) && Number(oldData.queue_position) > 0 &&
      (oldData.dispatch_status == null || oldData.dispatch_status === 'normal') &&
      (eventData.dispatch_status == null || eventData.dispatch_status === 'normal') &&
      !oldData.reserved_order_id && !eventData.reserved_order_id &&
      !oldData.active_order_id && !eventData.active_order_id &&
      !oldData.active_ride_id && !eventData.active_ride_id
    );

    const technicalTimestampOverwrite = Boolean(
      eventData && oldData &&
      oldData.status === 'disponible' &&
      eventData.status === 'disponible' &&
      oldData.current_base &&
      eventData.current_base === oldData.current_base &&
      oldData.queue_authoritative_base === oldData.current_base &&
      Number.isFinite(Number(oldData.queue_position)) && Number(oldData.queue_position) > 0 &&
      eventData.queue_entered_at !== oldData.queue_entered_at &&
      (oldData.dispatch_status == null || oldData.dispatch_status === 'normal') &&
      (eventData.dispatch_status == null || eventData.dispatch_status === 'normal') &&
      !oldData.reserved_order_id && !eventData.reserved_order_id &&
      !oldData.active_order_id && !eventData.active_order_id &&
      !oldData.active_ride_id && !eventData.active_ride_id
    );

    if (technicalBaseDrop || technicalTimestampOverwrite) {
      const previousBase = oldData.current_base;
      const previousAt = oldData.queue_authoritative_at || oldData.queue_entered_at || null;
      const restored = await b44.entities.Driver.updateMany(
        {
          id:driverId,
          status:'disponible',
          $or: [{ current_base: null }, { current_base: previousBase }],
          dispatch_status:eventData.dispatch_status ?? 'normal',
          reserved_order_id:null,
          active_order_id:null,
          active_ride_id:null,
          queue_position:eventData.queue_position ?? null,
          queue_authority_marker:eventData.queue_authority_marker ?? null,
          manual_reorder_token:eventData.manual_reorder_token ?? null
        },
        { $set:{
          current_base:previousBase,
          queue_entered_at:oldData.queue_entered_at || previousAt,
          queue_authoritative_base:previousBase,
          queue_authoritative_at:previousAt,
          queue_position:oldData.queue_position,
          queue_authority_marker:oldData.queue_authority_marker ?? oldData.queue_position,
          queue_left_at:null
        } }
      ).catch(()=>({updated:0}));
      const restoredCount = restored?.updated ?? restored?.modifiedCount ?? restored?.matchedCount ?? 0;

      if (restoredCount === 1) {
        await b44.entities.AuditLog.create({
          action: technicalBaseDrop ? 'LEGACY_TECHNICAL_BASE_NULL_RESTORED' : 'TECHNICAL_TIMESTAMP_OVERWRITE_RESTORED',
          user_type:'sistema',
          user_name:eventData.name || oldData.name || 'Driver',
          details:`Se ignoró un cambio técnico (null o timestamp) y ${eventData.name || oldData.name || driverId} conservó posición ${oldData.queue_position} en ${previousBase}`,
          metadata:{
            driverId,
            baseName:previousBase,
            preservedQueuePosition:oldData.queue_position,
            preservedQueueAt:previousAt,
            apkCompatibility:true
          }
        }).catch(()=>{});
      }

      return Response.json({ success:true, repaired:restoredCount === 1, reason: technicalBaseDrop ? 'LEGACY_TECHNICAL_BASE_NULL_RESTORED' : 'TECHNICAL_TIMESTAMP_OVERWRITE_RESTORED' });
    }

    // Compatibilidad v12.27/v12.29: esas APK todavía implementan RECHAZAR liberando
    // primero el Driver directamente y pidiendo la reasignación después. Ese cambio
    // NO es una limpieza fantasma: si lo restauramos desde el guard, Central y el
    // teléfono compiten por la misma oferta y pueden dejar driver_id/reserved_driver_id
    // cruzados. Reconocemos únicamente la transición exacta de rechazo viejo.
    const legacyDirectReject = Boolean(
      eventData && oldData &&
      oldData.status === 'disponible' &&
      oldData.dispatch_status === 'automatic_pending' &&
      oldData.reserved_order_id &&
      oldData.reservation_token &&
      eventData.status === 'disponible' &&
      (eventData.dispatch_status == null || eventData.dispatch_status === 'normal') &&
      !eventData.reserved_order_id &&
      !eventData.active_order_id &&
      !eventData.active_ride_id &&
      eventData.queue_entered_at &&
      eventData.queue_entered_at !== oldData.queue_entered_at
    );

    if (legacyDirectReject) {
      const legacyOrderId = oldData.reserved_order_id;
      const legacyOrder = await b44.entities.RideOrder.get(legacyOrderId).catch(() => null);
      const stillSameOffer = Boolean(
        legacyOrder &&
        legacyOrder.status === 'ofrecido' &&
        legacyOrder.reserved_driver_id === driverId &&
        legacyOrder.reservation_token === oldData.reservation_token
      );

      if (stillSameOffer) {
        const expiresAt = Number(legacyOrder.offerExpiresAt);
        const offerStillLive = !Number.isFinite(expiresAt) || Date.now() < expiresAt;

        if (offerStillLive) {
          // Una APK legacy puede liberar el Driver por lógica local vieja aunque el
          // chofer NO haya rechazado. Mientras la oferta siga vigente, esa escritura
          // jamás es autoridad para reasignar: restauramos exactamente la reserva.
          const restored = await b44.entities.Driver.updateMany(
            {
              id: driverId,
              status: 'disponible',
              $or: [
                { dispatch_status: 'normal' },
                { dispatch_status: null },
                { dispatch_status: { $exists:false } }
              ],
              reserved_order_id: null,
              active_order_id: null,
              active_ride_id: null
            },
            { $set: {
              dispatch_status: 'automatic_pending',
              reserved_order_id: legacyOrder.id,
              reservation_token: legacyOrder.reservation_token,
              current_base: legacyOrder.assigned_base || oldData.current_base || eventData.current_base || null,
              queue_entered_at: oldData.queue_entered_at || eventData.queue_entered_at || null
            } }
          ).catch(() => ({ updated:0 }));
          const restoredCount = restored?.updated ?? restored?.modifiedCount ?? restored?.matchedCount ?? 0;

          await b44.entities.AuditLog.create({
            action:'LEGACY_PREMATURE_RELEASE_RESTORED',
            user_type:'sistema',
            user_name:eventData.name || oldData.name || 'Driver',
            details:`Se bloqueó una liberación legacy antes de vencer la oferta ${legacyOrder.id}`,
            metadata:{
              orderId:legacyOrder.id,
              driverId,
              assignmentAttempt:legacyOrder.assignment_attempt,
              offerExpiresAt:legacyOrder.offerExpiresAt ?? null,
              remainingMs:Number.isFinite(expiresAt) ? Math.max(0, expiresAt - Date.now()) : null,
              restored:restoredCount === 1
            }
          }).catch(()=>{});

          return Response.json({
            success:true,
            repaired:restoredCount === 1,
            reason:'LEGACY_PREMATURE_RELEASE_RESTORED'
          });
        }

        // Si ya venció de verdad, primero restauramos la propiedad exacta y luego
        // dejamos que el motor server-side procese el timeout. Así la APK nunca
        // decide por sí sola cuándo saltar al siguiente móvil.
        await b44.entities.Driver.updateMany(
          { id:driverId, status:'disponible', reserved_order_id:null, active_order_id:null, active_ride_id:null },
          { $set:{
            dispatch_status:'automatic_pending',
            reserved_order_id:legacyOrder.id,
            reservation_token:legacyOrder.reservation_token,
            current_base:legacyOrder.assigned_base || oldData.current_base || eventData.current_base || null,
            queue_entered_at:oldData.queue_entered_at || eventData.queue_entered_at || null
          } }
        ).catch(()=>{});

        const timeoutRes = await b44.functions.invoke('rejectRide', {
          orderId: legacyOrder.id,
          driverId,
          assignmentAttempt: Number(legacyOrder.assignment_attempt || 1),
          source: 'timeout',
          internalKey: Deno.env.get('INTERNAL_SERVICE_KEY')
        }).catch((error:any) => ({ data:{ success:false, reason:error?.message || 'INVOKE_FAILED' } }));
        const timeoutData = timeoutRes?.data || timeoutRes;
        return Response.json({
          success:timeoutData?.success !== false,
          repaired:true,
          reason:'LEGACY_RELEASE_CONVERTED_TO_SERVER_TIMEOUT',
          timeoutResult:timeoutData
        });
      }

      // La oferta ya cambió de dueño/estado antes de que corriera este evento legacy.
      // La regla actual es rechazo/timeout = CONSERVA SU MISMA POSICIÓN en la base.
      // Restablecemos la base y posición exacta que tenía el chofer antes de la oferta
      // para evitar que la APK vieja (que pone la base en null temporalmente) le haga 
      // perder el lugar.
      const releasedDriver = await b44.entities.Driver.get(driverId).catch(()=>null);
      const queueBase = legacyOrder?.assigned_base || legacyOrder?.zone || oldData.current_base || eventData.current_base || null;
      const previousAuthorityAt = oldData.queue_authoritative_at || oldData.queue_entered_at || null;
      const previousQueuePosition = Number(oldData.queue_position);
      const hasPreviousQueuePosition =
        oldData.queue_authoritative_base === queueBase &&
        Number.isFinite(previousQueuePosition) &&
        previousQueuePosition > 0;
      
      let reconciled = false;
      if (releasedDriver && queueBase &&
          releasedDriver.status === 'disponible' &&
          (releasedDriver.dispatch_status == null || releasedDriver.dispatch_status === 'normal') &&
          !releasedDriver.reserved_order_id && !releasedDriver.active_order_id && !releasedDriver.active_ride_id &&
          (!releasedDriver.current_base || releasedDriver.current_base === queueBase)) {
        
        const res = await b44.entities.Driver.updateMany(
          {
            id: driverId,
            status: 'disponible',
            $or:[{ current_base:null }, { current_base:queueBase }],
            reserved_order_id: null,
            active_order_id: null,
            active_ride_id: null,
            queue_position: releasedDriver.queue_position ?? null,
            queue_authority_marker: releasedDriver.queue_authority_marker ?? null,
            manual_reorder_token: releasedDriver.manual_reorder_token ?? null
          },
          {
            $set: {
              current_base: queueBase,
              queue_authoritative_base: queueBase,
              queue_entered_at: oldData.queue_entered_at || previousAuthorityAt,
              queue_authoritative_at: previousAuthorityAt,
              ...(hasPreviousQueuePosition ? {
                queue_position: previousQueuePosition,
                queue_authority_marker: oldData.queue_authority_marker ?? previousQueuePosition
              } : {})
            }
          }
        );
        reconciled = (res?.updated ?? res?.modifiedCount ?? res?.matchedCount ?? 0) === 1;
      }

      await b44.entities.AuditLog.create({
        action:'LEGACY_RELEASE_RECONCILED_POSITION_KEPT',
        user_type:'sistema',
        user_name:eventData.name || oldData.name || 'Driver',
        details:`Cierre legacy conciliado; ${driverId} conservó su posición en cola server-side en ${queueBase}`,
        metadata:{
          driverId,
          orderId:legacyOrderId,
          baseName:queueBase,
          reconciled
        }
      }).catch(()=>{});

      return Response.json({ success:true, repaired:reconciled, reason:'LEGACY_RELEASE_RECONCILED_POSITION_KEPT' });
    }

    // AUTORIDAD SERVER-SIDE DE COLA.
    // queue_position decide el orden real. queue_entered_at/queue_authoritative_at
    // quedan como historial/proyección para las APK v12.27/v12.29 y nunca dan prioridad.
    const freshQueueDriver = await b44.entities.Driver.get(driverId).catch(() => null);
    if (freshQueueDriver) {
      const currentBase = freshQueueDriver.current_base || null;
      const authoritativeBase = freshQueueDriver.queue_authoritative_base || null;
      const currentAt = freshQueueDriver.queue_entered_at || null;
      const authoritativeAt = freshQueueDriver.queue_authoritative_at || null;
      const marker = freshQueueDriver.queue_position ?? null;
      const acceptedMarker = freshQueueDriver.queue_authority_marker ?? null;
      const explicitManualMove = marker != null && String(marker) !== String(acceptedMarker);
      const queueIdle =
        freshQueueDriver.status === 'disponible' &&
        (freshQueueDriver.dispatch_status == null || freshQueueDriver.dispatch_status === 'normal') &&
        !freshQueueDriver.reserved_order_id &&
        !freshQueueDriver.active_order_id &&
        !freshQueueDriver.active_ride_id;

      // APK legacy: al volver A SERVICIO puede publicar primero disponible+sin base
      // conservando la autoridad/posición de la sesión anterior. Esa autoridad es
      // inválida: si la dejamos viva, al elegir base puede reaparecer 1° con su
      // queue_position viejo. La transición real no_disponible -> disponible sin
      // base abre una sesión nueva y debe esperar una entrada de base desde cero.
      const legacyServiceOnWithoutBase = Boolean(
        oldData && eventData &&
        oldData.status === 'no_disponible' &&
        eventData.status === 'disponible' &&
        !eventData.current_base &&
        !freshQueueDriver.current_base &&
        !freshQueueDriver.reserved_order_id &&
        !freshQueueDriver.active_order_id &&
        !freshQueueDriver.active_ride_id
      );
      if (legacyServiceOnWithoutBase && (authoritativeBase || authoritativeAt || freshQueueDriver.queue_position != null)) {
        const cleared = await b44.entities.Driver.updateMany(
          {
            id:driverId,
            status:'disponible',
            current_base:null,
            reserved_order_id:null,
            active_order_id:null,
            active_ride_id:null
          },
          { $set:{
            queue_authoritative_base:null,
            queue_authoritative_at:null,
            queue_authority_marker:null,
            queue_position:null,
            queue_entered_at:null,
            queue_left_at:new Date().toISOString()
          } }
        ).catch(()=>({updated:0}));
        const clearedCount = cleared?.updated ?? cleared?.modifiedCount ?? cleared?.matchedCount ?? 0;
        if (authoritativeBase && clearedCount === 1) compactQueue(b44, authoritativeBase).catch(()=>null);
        if (clearedCount === 1) {
          await b44.entities.AuditLog.create({
            action:'QUEUE_STALE_AUTHORITY_CLEARED_ON_SERVICE_START',
            user_type:'sistema',
            user_name:freshQueueDriver.name || oldData.name || 'Driver',
            details:`Se limpió posición vieja de ${freshQueueDriver.name || driverId} al volver a servicio sin base`,
            metadata:{ driverId, previousBase:authoritativeBase, previousPosition:marker }
          }).catch(()=>{});
        }
        return Response.json({ success:true, repaired:clearedCount === 1, reason:'QUEUE_STALE_AUTHORITY_CLEARED_ON_SERVICE_START' });
      }

      // Salida real de servicio: status=no_disponible + current_base=null invalida
      // SIEMPRE la autoridad de cola. Las APK 12.27/12.29 pueden dejar un
      // queue_entered_at viejo en caché; ese timestamp nunca puede mantener vivo un puesto.
      const explicitOffServiceExit = Boolean(
        freshQueueDriver.status === 'no_disponible' &&
        !freshQueueDriver.current_base
      );
      if (explicitOffServiceExit && (authoritativeBase || authoritativeAt || freshQueueDriver.queue_position != null)) {
        await b44.entities.Driver.updateMany(
          { id:driverId, status:'no_disponible', current_base:null },
          { $set:{
            queue_authoritative_base:null,
            queue_authoritative_at:null,
            queue_authority_marker:null,
            queue_position:null,
            queue_entered_at:null,
            queue_left_at:new Date().toISOString()
          } }
        ).catch(()=>{});
        if (authoritativeBase) compactQueue(b44, authoritativeBase).catch(()=>null);
        return Response.json({ success:true, repaired:true, reason:'QUEUE_AUTHORITY_CLEARED_EXPLICIT_OFF_SERVICE' });
      }

      if (freshQueueDriver && oldData && eventData) {
        const hadValidAuthority = Boolean(
          oldData.status === 'disponible' && oldData.current_base &&
          oldData.queue_authoritative_base === oldData.current_base &&
          Number.isFinite(Number(oldData.queue_position)) && Number(oldData.queue_position) > 0
        );
        const writeKeepsIdleInSameBase = Boolean(
          eventData.status === 'disponible' && eventData.current_base &&
          eventData.current_base === oldData.current_base &&
          (eventData.dispatch_status == null || eventData.dispatch_status === 'normal') &&
          !eventData.reserved_order_id && !eventData.active_order_id && !eventData.active_ride_id
        );
        const commercialAction = Boolean(
          oldData.reserved_order_id || eventData.reserved_order_id ||
          (oldData.dispatch_status && oldData.dispatch_status !== 'normal') ||
          (eventData.dispatch_status && eventData.dispatch_status !== 'normal') ||
          oldData.current_base !== eventData.current_base ||
          oldData.status !== eventData.status
        );

        const attemptedAt = (eventData.queue_authoritative_at || eventData.queue_entered_at) ?? null;
        const manualAuthorized = await verifyReorderToken(
          eventData.manual_reorder_token ?? null,
          driverId, eventData.current_base ?? null, attemptedAt
        );
        const serverStampedPosition = Boolean(
          Number.isFinite(Number(eventData.queue_position)) && Number(eventData.queue_position) > 0 &&
          String(eventData.queue_authority_marker ?? '') === String(eventData.queue_position) &&
          (
            String(eventData.queue_position ?? '') !== String(oldData.queue_position ?? '') ||
            String(eventData.queue_authority_marker ?? '') !== String(oldData.queue_authority_marker ?? '')
          )
        );

        if (hadValidAuthority && writeKeepsIdleInSameBase && !commercialAction) {
          if (manualAuthorized || serverStampedPosition) {
            return Response.json({ success:true, reason:manualAuthorized ? 'MANUAL_REORDER_AUTHORIZED' : 'SERVER_QUEUE_POSITION_AUTHORIZED' });
          }

          const restoreRes = await b44.entities.Driver.updateMany(
            {
              id: driverId,
              status: 'disponible',
              current_base: oldData.current_base,
              queue_position: freshQueueDriver.queue_position ?? null,
              queue_authority_marker: freshQueueDriver.queue_authority_marker ?? null,
              manual_reorder_token: freshQueueDriver.manual_reorder_token ?? null,
              $or: [
                { queue_authoritative_base: null }, { queue_authoritative_base: { $exists:false } },
                { queue_authoritative_at: null }, { queue_authoritative_at: { $exists:false } },
                { queue_authoritative_at: { $ne: oldData.queue_authoritative_at } },
                { queue_entered_at: { $ne: oldData.queue_entered_at } },
                { queue_position: { $ne: oldData.queue_position } },
                { queue_authority_marker: { $ne: oldData.queue_authority_marker ?? oldData.queue_position } },
                { manual_reorder_token: { $ne: oldData.manual_reorder_token ?? null } }
              ]
            },
            { $set: {
              current_base: oldData.current_base,
              queue_entered_at: oldData.queue_entered_at,
              queue_authoritative_base: oldData.queue_authoritative_base,
              queue_authoritative_at: oldData.queue_authoritative_at,
              queue_position: oldData.queue_position,
              queue_authority_marker: oldData.queue_authority_marker ?? oldData.queue_position,
              manual_reorder_token: oldData.manual_reorder_token ?? null,
              manual_reorder_at: oldData.manual_reorder_at ?? null
            } }
          ).catch(()=>({updated:0}));
          const restoredCount = restoreRes?.updated ?? restoreRes?.modifiedCount ?? restoreRes?.matchedCount ?? 0;
          
          if (restoredCount === 1) {
            await b44.entities.AuditLog.create({
              action: 'QUEUE_AUTHORITY_IMMUTABLE_RESTORED',
              user_type: 'sistema',
              user_name: freshQueueDriver.name || oldData.name || 'Driver',
              details: `Se preservó la antigüedad de ${freshQueueDriver.name || driverId} en ${oldData.current_base} frente a una escritura técnica`,
              metadata: {
                driverId, baseName: oldData.current_base,
                preservedAuthoritativeAt: oldData.queue_authoritative_at,
                attemptedAuthoritativeBase: freshQueueDriver.queue_authoritative_base ?? null,
                attemptedAuthoritativeAt: freshQueueDriver.queue_authoritative_at ?? null,
                attemptedQueueEnteredAt: freshQueueDriver.queue_entered_at ?? null,
                attemptedQueuePosition: freshQueueDriver.queue_position ?? null,
                oldDispatchStatus: oldData.dispatch_status ?? null,
                newDispatchStatus: eventData.dispatch_status ?? null,
                oldReservedOrderId: oldData.reserved_order_id ?? null,
                newReservedOrderId: eventData.reserved_order_id ?? null,
                hadManualReorderToken: Boolean(eventData.manual_reorder_token),
                origin: eventData.device_id ? 'apk' : (eventData.fcm_token ? 'mobile' : 'unknown')
              }
            }).catch(()=>{});
          }
          return Response.json({ success:true, repaired: restoredCount===1, reason:'QUEUE_AUTHORITY_IMMUTABLE_RESTORED' });
        }
      }

      if (queueIdle) {
        // Entrar en servicio también es una entrada NUEVA aunque la APK conserve
        // current_base/queue_entered_at viejos en caché. Nunca se hereda antigüedad.
        const enteredService = Boolean(
          currentBase && oldData && eventData &&
          oldData.status !== 'disponible' && eventData.status === 'disponible'
        );
        if (enteredService) {
          const placed = await placeDriverLastLocked(
            currentBase,
            driverId,
            { id:driverId, status:'disponible', current_base:currentBase },
            { queue_authority_marker:null }
          );
          const serviceEntryAt = placed.queueAt;
          const serviceEntryCount = placed.count;
          if (serviceEntryCount !== 1) {
            return Response.json({ success:true, repaired:false, reason:'QUEUE_SERVICE_ENTRY_CHANGED_CONCURRENTLY' });
          }
          await b44.entities.AuditLog.create({
            action:'QUEUE_SERVICE_ENTRY_AT_TAIL', user_type:'sistema', user_name:freshQueueDriver.name || 'Driver',
            details:`${freshQueueDriver.name || driverId} entró en servicio y quedó último en ${currentBase}`,
            metadata:{ driverId, baseName:currentBase, queueAt:serviceEntryAt }
          }).catch(()=>{});
          normalizedExplicitQueueEntry = true;
        }

        // Reingreso desde "sin base": SIEMPRE es una entrada nueva.
        // No existe gracia: al tocar cualquier base, incluso la misma, queda detrás del último.
        // Un oldData.current_base=null puede ser una proyección técnica/atrasada de APK.
        // Si el estado FRESCO ya conserva autoridad válida en esta misma base, no es
        // un reingreso real y jamás debe renovar antigüedad ni mandar el móvil al final.
        const freshHasContinuousAuthority = Boolean(
          currentBase && authoritativeBase === currentBase &&
          Number(freshQueueDriver.queue_position || 0) > 0
        );
        const returnedFromNoBase = Boolean(
          !normalizedExplicitQueueEntry && currentBase && oldData && !oldData.current_base &&
          !freshHasContinuousAuthority
        );
        if (returnedFromNoBase) {
          const placed = await placeDriverLastLocked(
            currentBase,
            driverId,
            { id:driverId, status:'disponible', current_base:currentBase },
            { queue_authority_marker:null }
          );
          const newEntryAt = placed.queueAt;
          const resetCount = placed.count;
          if (resetCount === 1) {
            await b44.entities.AuditLog.create({
              action:'QUEUE_REENTRY_AT_TAIL',
              user_type:'sistema',
              user_name:freshQueueDriver.name || 'Driver',
              details:`${freshQueueDriver.name || driverId} reingresó y quedó último en ${currentBase}`,
              metadata:{ driverId, previousBase:authoritativeBase, newBase:currentBase, queueAt:newEntryAt, graceStillActive:false }
            }).catch(()=>{});
          }
          if (resetCount !== 1) {
            return Response.json({ success:true, repaired:false, reason:'QUEUE_REENTRY_CHANGED_CONCURRENTLY' });
          }
          normalizedExplicitQueueEntry = true;
          // No retornar: esta entrada nueva creó capacidad real y debe intentar
          // despachar un Pendiente de la misma zona en este mismo evento.
        }

        // Primera entrada sin autoridad: NUNCA confiar en queue_entered_at enviado por
        // la APK (puede ser viejo y meter al móvil primero). La entrada nace detrás
        // del último snapshot autoritativo de la base.
        if (!normalizedExplicitQueueEntry && !authoritativeBase && currentBase) {
          const placed = await placeDriverLastLocked(
            currentBase,
            driverId,
            { id:driverId, status:'disponible', current_base:currentBase },
            { queue_authority_marker:null }
          );
          const seedAt = placed.queueAt;
          const seededCount = placed.count;
          if (seededCount !== 1) {
            return Response.json({ success:true, repaired:false, reason:'QUEUE_AUTHORITY_INITIALIZE_CHANGED_CONCURRENTLY' });
          }
          await b44.entities.AuditLog.create({
            action:'QUEUE_AUTHORITY_INITIALIZED', user_type:'sistema', user_name:freshQueueDriver.name || 'Driver',
            details:`Entrada de ${freshQueueDriver.name || driverId} registrada al final de ${currentBase} con hora autoritativa del servidor`,
            metadata:{ driverId, baseName:currentBase, queueAt:seedAt }
          }).catch(()=>{});
          normalizedExplicitQueueEntry = true;
          // No retornar: la misma entrada autoritativa debe continuar hasta el motor
          // de Pendientes en lugar de depender de un segundo evento realtime.
        }

        // REGLA OPERATIVA INMUTABLE: un móvil ya agendado NO pierde su posición por
        // GPS, heartbeat, reconexión, caché ni current_base=null técnico. Mientras siga
        // disponible/normal y sin viaje o reserva, la autoridad de cola manda y se
        // restaura la base anterior. Sólo una salida de servicio real o un pasaje puede
        // quitarlo de posición; el cambio voluntario A->B se procesa explícitamente abajo.
        const previousEventStillOwnedAuthority = Boolean(
          oldData && authoritativeBase &&
          oldData.status === 'disponible' &&
          oldData.current_base === authoritativeBase &&
          oldData.queue_authoritative_base === authoritativeBase &&
          Number.isFinite(Number(oldData.queue_position)) && Number(oldData.queue_position) > 0 &&
          !oldData.reserved_order_id && !oldData.active_order_id && !oldData.active_ride_id &&
          (oldData.dispatch_status == null || oldData.dispatch_status === 'normal')
        );
        if (!normalizedExplicitQueueEntry && authoritativeBase && !currentBase && previousEventStillOwnedAuthority) {
          const restored = await b44.entities.Driver.updateMany(
            {
              id:driverId,
              status:'disponible',
              current_base:null,
              dispatch_status:'normal',
              reserved_order_id:null,
              active_order_id:null,
              active_ride_id:null,
              queue_position:freshQueueDriver.queue_position ?? null,
              queue_authority_marker:freshQueueDriver.queue_authority_marker ?? null,
              manual_reorder_token:freshQueueDriver.manual_reorder_token ?? null
            },
            { $set:{
              current_base:authoritativeBase,
              queue_entered_at:authoritativeAt || currentAt,
              queue_authoritative_base:authoritativeBase,
              queue_authoritative_at:authoritativeAt || currentAt,
              queue_position:oldData.queue_position,
              queue_authority_marker:oldData.queue_authority_marker ?? oldData.queue_position,
              queue_left_at:null
            } }
          ).catch(()=>({updated:0}));
          const restoredCount = restored?.updated ?? restored?.modifiedCount ?? restored?.matchedCount ?? 0;
          if (restoredCount === 1) {
            await b44.entities.AuditLog.create({
              action:'QUEUE_POSITION_PRESERVED_AGAINST_TECHNICAL_EXIT',
              user_type:'sistema',
              user_name:freshQueueDriver.name || 'Driver',
              details:`${freshQueueDriver.name || driverId} intentó quedar sin base por una escritura técnica; se preservó su posición en ${authoritativeBase}`,
              metadata:{ driverId, baseName:authoritativeBase, preservedQueueAt:authoritativeAt || currentAt, preservedQueuePosition:marker ?? acceptedMarker }
            }).catch(()=>{});
          }
          return Response.json({ success:true, repaired:restoredCount === 1, reason:'QUEUE_POSITION_PRESERVED_AGAINST_TECHNICAL_EXIT' });
        }

        // Cambio A->B: las APK instaladas hacen el cambio voluntario escribiendo
        // current_base Y una nueva queue_entered_at en la misma acción. Esa pareja
        // es nuestra señal compatible de intención sin exigir campos nuevos al APK.
        // Un heartbeat/reconexión/cache que sólo haga oscilar current_base NO puede
        // mover al chofer ni renovar su posición: se revierte a la autoridad previa.
        if (!normalizedExplicitQueueEntry && authoritativeBase && currentBase && authoritativeBase !== currentBase) {
          const explicitDriverBaseEntry = Boolean(
            eventData && oldData &&
            oldData.current_base === authoritativeBase &&
            eventData.current_base === currentBase &&
            eventData.queue_entered_at &&
            eventData.queue_entered_at !== oldData.queue_entered_at
          );

          if (explicitDriverBaseEntry) {
            // Cambio/entrada real de base: la hora del teléfono NO define la posición.
            // El servidor serializa la nueva base y lo deja último por queue_position.
            const placed = await placeDriverLastLocked(
              currentBase,
              driverId,
              { id:driverId, status:'disponible', current_base:currentBase, queue_entered_at:currentAt }
            );
            const newAuthoritativeAt = placed.queueAt;
            if (placed.count === 1 && authoritativeBase) await compactQueue(b44, authoritativeBase).catch(()=>null);
            await b44.entities.AuditLog.create({
              action:'QUEUE_AUTHORITY_BASE_CHANGED', user_type:'sistema', user_name:freshQueueDriver.name || 'Driver',
              details:`Entrada voluntaria de base aceptada para ${freshQueueDriver.name || driverId}: ${authoritativeBase} → ${currentBase}`,
              metadata:{ driverId, oldBase:authoritativeBase, newBase:currentBase, queueAt:newAuthoritativeAt }
            }).catch(()=>{});
          } else {
            const restored = await b44.entities.Driver.updateMany(
              {
                id:driverId,
                status:'disponible',
                current_base:currentBase,
                reserved_order_id:null,
                active_order_id:null,
                active_ride_id:null,
                queue_authoritative_base:authoritativeBase,
                queue_position:marker ?? null,
                queue_authority_marker:acceptedMarker ?? null,
                manual_reorder_token:freshQueueDriver.manual_reorder_token ?? null
              },
              { $set:{
                current_base:authoritativeBase,
                queue_entered_at:oldData?.queue_entered_at ?? currentAt,
                queue_authoritative_base:oldData?.queue_authoritative_base ?? authoritativeBase,
                queue_authoritative_at:oldData?.queue_authoritative_at ?? authoritativeAt,
                queue_position:oldData?.queue_position ?? marker,
                queue_authority_marker:oldData?.queue_authority_marker ?? oldData?.queue_position ?? acceptedMarker ?? marker,
                queue_left_at:null
              } }
            ).catch(()=>({updated:0}));
            const count = restored?.updated ?? restored?.modifiedCount ?? restored?.matchedCount ?? 0;
            if (count === 1) {
              await b44.entities.AuditLog.create({
                action:'QUEUE_GHOST_BASE_CHANGE_REVERTED', user_type:'sistema', user_name:freshQueueDriver.name || 'Driver',
                details:`Cambio técnico de base revertido para ${freshQueueDriver.name || driverId}; posición preservada`,
                metadata:{ driverId, attemptedBase:currentBase, restoredBase:authoritativeBase, restoredQueueAt:authoritativeAt }
              }).catch(()=>{});
            }
            return Response.json({ success:true, repaired:count === 1, reason:'GHOST_BASE_CHANGE_REVERTED' });
          }
        }
      }
    }

    // Primero proteger la integridad Driver ↔ RideOrder. Este chequeo corre también
    // cuando queue_entered_at no cambió, porque una APK vieja puede borrar la reserva
    // desde un heartbeat GPS sin tocar la posición de cola.
    await guardOfferedReservationIntegrity(b44, driverId);

    // BLINDAJE ESTRICTO DE COLA.
    // Una vez que un móvil está DISPONIBLE dentro de una base, su antigüedad es
    // INMUTABLE. El operador sólo puede reordenarlo mediante el flujo firmado
    // manualReorderDriverQueue, que fue validado arriba y retorna antes de llegar acá.
    // Rechazos, vencimientos, reconexiones, GPS, heartbeat o cualquier escritura
    // técnica de una APK legacy NO pueden cambiar su lugar dentro de la misma base.
    // Salir/cambiar/entrar de base tampoco cae en este guard porque cambia base/estado.
    // Por lo tanto, cualquier cambio de queue_entered_at que llegue hasta aquí mientras
    // sigue disponible en la MISMA base se revierte sin excepciones.
    const oldDispatch = oldData?.dispatch_status ?? 'normal';
    const newDispatch = eventData?.dispatch_status ?? 'normal';
    const queueTimestampChanged = Boolean(
      eventData && oldData &&
      eventData.queue_entered_at !== oldData.queue_entered_at
    );
    const sameBase = Boolean(
      eventData?.current_base &&
      eventData.current_base === oldData?.current_base
    );
    // IMPORTANTE v12.27: perder/rechazar/vencer una oferta NO autoriza una nueva
    // antigüedad de cola. La APK legacy escribe queue_entered_at al liberar, pero
    // esa hora es un efecto técnico de su código viejo, no una entrada voluntaria.
    // El caso se procesa arriba por legacyDirectReject/rejectRide y queda fuera de
    // cola hasta una entrada explícita posterior. Por eso lostOffer NO se exceptúa
    // del guard de misma base.
    const unauthorizedSameBaseMove = Boolean(
      queueTimestampChanged &&
      sameBase &&
      oldData?.queue_entered_at &&
      oldData?.status === 'disponible' &&
      eventData?.status === 'disponible'
    );

    if (unauthorizedSameBaseMove) {
      const reverted = await b44.entities.Driver.updateMany(
        {
          id: driverId,
          current_base: eventData.current_base,
          status: 'disponible',
          queue_entered_at: eventData.queue_entered_at
        },
        { $set: {
          queue_entered_at: oldData.queue_entered_at
        } }
      );
      const changed = reverted?.updated ?? reverted?.modifiedCount ?? reverted?.matchedCount ?? 0;
      if (changed === 1) {
        await b44.entities.AuditLog.create({
          action: 'QUEUE_UNAUTHORIZED_MOVE_REVERTED',
          user_type: 'sistema',
          user_name: eventData.name || oldData.name || 'Driver',
          details: `Movimiento de cola no autorizado revertido para ${eventData.name || oldData.name || driverId}`,
          metadata: {
            driverId,
            baseName: eventData.current_base,
            attemptedQueueEnteredAt: eventData.queue_entered_at ?? null,
            restoredQueueEnteredAt: oldData.queue_entered_at ?? null,
            oldDispatchStatus: oldDispatch,
            newDispatchStatus: newDispatch,
            oldReservedOrderId: oldData.reserved_order_id ?? null,
            newReservedOrderId: eventData.reserved_order_id ?? null
          }
        }).catch(() => {});
        return Response.json({ success:true, repaired:true, reason:'UNAUTHORIZED_SAME_BASE_MOVE_REVERTED' });
      }
      // Si el CAS no matcheó, otra operación legítima ganó la carrera: no tocarla.
      return Response.json({ success:true, skipped:true, reason:'QUEUE_CHANGED_DURING_STRICT_GUARD' });
    }

    // CORTE OPERATIVO URGENTE: este workflow NO debe despachar Pendientes a partir
    // de una simple escritura de queue_entered_at. Las APK legacy/reconexiones pueden
    // tocar esa proyección y eso estaba creando capacidad falsa, moviendo posiciones
    // y entregando un pendiente a un móvil que no correspondía. Sólo una entrada o
    // cambio REAL de base, o un movimiento manual explícito del operador, habilita
    // el drenaje automático de un pendiente. El despacho normal/rechazo/timeout
    // sigue siendo autoridad de assignRide/rejectRide y no depende de este trigger.
    const explicitQueueEntryOrMove = Boolean(
      normalizedExplicitQueueEntry ||
      (eventData && oldData && (
        (
          eventData.status === 'disponible' &&
          eventData.current_base &&
          eventData.current_base !== oldData.current_base &&
          eventData.queue_entered_at &&
          eventData.queue_entered_at !== oldData.queue_entered_at
        ) ||
        (
          eventData.status === 'disponible' &&
          eventData.current_base &&
          eventData.current_base === oldData.current_base &&
          eventData.queue_position !== oldData.queue_position &&
          eventData.queue_entered_at &&
          eventData.queue_entered_at !== oldData.queue_entered_at
        )
      ))
    );
    if (!explicitQueueEntryOrMove) {
      return Response.json({ success: true, skipped: true, reason: 'NO_EXPLICIT_QUEUE_ENTRY_FOR_PENDING_DISPATCH' });
    }

    // Trazabilidad de cola: registrar toda modificación REAL de antigüedad. Esto no
    // cambia posiciones; solo permite saber si vino de una entrada, rechazo, timeout
    // o una acción manual y detectar cualquier escritura inesperada en producción.
    if (eventData && oldData && eventData.queue_entered_at !== oldData.queue_entered_at) {
      await b44.entities.AuditLog.create({
        action: 'QUEUE_TIMESTAMP_CHANGED',
        user_type: 'sistema',
        user_name: eventData.name || oldData.name || 'Driver',
        details: `Cambió antigüedad de cola de ${eventData.name || oldData.name || driverId}`,
        metadata: {
          driverId,
          oldQueueEnteredAt: oldData.queue_entered_at ?? null,
          newQueueEnteredAt: eventData.queue_entered_at ?? null,
          oldBase: oldData.current_base ?? null,
          newBase: eventData.current_base ?? null,
          oldStatus: oldData.status ?? null,
          newStatus: eventData.status ?? null,
          oldDispatchStatus: oldData.dispatch_status ?? null,
          newDispatchStatus: eventData.dispatch_status ?? null
        }
      }).catch(() => {});
    }

    const triggerDriver = await b44.entities.Driver.get(driverId).catch(() => null);
    if (!triggerDriver) {
      return Response.json({ success: true, skipped: true, reason: 'DRIVER_NOT_FOUND' });
    }

    const zone = triggerDriver.current_base;
    const triggerIsAvailable =
      triggerDriver.status === 'disponible' &&
      Boolean(zone) &&
      (triggerDriver.dispatch_status == null || triggerDriver.dispatch_status === 'normal') &&
      !triggerDriver.active_order_id &&
      !triggerDriver.active_ride_id &&
      !triggerDriver.reserved_order_id;

    // Si el móvil ya recibió otro viaje entre que entró a la base y corrió el
    // workflow, no hay capacidad nueva que drenar y no tocamos nada.
    if (!triggerIsAvailable) {
      return Response.json({ success: true, skipped: true, reason: 'TRIGGER_DRIVER_NOT_AVAILABLE' });
    }

    // Una entrada de móvil habilita como máximo UNA nueva asignación. El candidato
    // real se vuelve a elegir por la cola oficial de la zona; no se fuerza al móvil
    // que disparó el evento. Así se conserva estrictamente el orden de lista.
    // Si otro trigger gana una carrera, reintentamos unas pocas veces sobre el
    // estado fresco sin duplicar el motor de reservas de assignRide.
    const failedByOrder = new Map<string, Set<string>>();
    const MAX_RACE_RETRIES = 8;

    for (let retry = 0; retry < MAX_RACE_RETRIES; retry++) {
      const pendings = await b44.entities.RideOrder.filter(
        { status: 'pendiente', zone },
        'created_date',
        12
      ).catch(() => []);

      const nowMs = Date.now();
      const eligiblePendings = pendings.filter((order: any) => {
        const heldForReview = String(order.notes || '').includes(CENTRAL_REVIEW_MARKER);
        const lifecycleAlreadyAdvanced = PROTECTED_ACTIONS.has(String(order.lastCompletedAction || ''));
        const reassigning = order.processingPhase === 'REASSIGNING';
        // APK 12.27/v12.29 puede escribir `pendiente` conservando por unos segundos
        // la ventana/attempt de la oferta anterior. Eso es un estado transitorio de
        // la cadena A→B→C, no un Pendiente público. No lo consume este workflow.
        const offerExpiry = Number(order.offerExpiresAt);
        const legacyOfferWindowStillLive =
          Number(order.assignment_attempt || 0) > 0 &&
          Number.isFinite(offerExpiry) &&
          offerExpiry > nowMs;
        return !heldForReview && !lifecycleAlreadyAdvanced && !reassigning && !legacyOfferWindowStillLive;
      });

      if (eligiblePendings.length === 0) {
        return Response.json({ success: true, assigned: false, reason: 'NO_PENDING_IN_ZONE', zone });
      }

      // Prioridad FIFO: intentamos desde el pendiente más antiguo. Si ese pasaje
      // ya agotó candidatos válidos (por rechazos previos), probamos el siguiente
      // sin volver a ofrecerlo a un chofer que ya lo tuvo.
      let chosenOrder: any = null;
      let chosenDriver: any = null;

      for (const order of eligiblePendings) {
        const excluded = failedByOrder.get(order.id) || new Set<string>();
        const candidate = await findNextDriverInZone(b44, order, excluded);
        if (candidate) {
          chosenOrder = order;
          chosenDriver = candidate;
          break;
        }
      }

      if (!chosenOrder || !chosenDriver) {
        return Response.json({ success: true, assigned: false, reason: 'NO_ELIGIBLE_DRIVER_FOR_PENDING', zone });
      }

      const res = await b44.functions.invoke('assignRide', {
        orderId: chosenOrder.id,
        driverId: chosenDriver.id,
        requireDriverConfirmation: true,
        internalKey: Deno.env.get('INTERNAL_SERVICE_KEY')
      }).catch((error: any) => ({ data: { success: false, reason: error?.message || 'INVOKE_FAILED' } }));

      if (res?.data?.success === true) {
        await b44.entities.AuditLog.create({
          action: 'PENDING_AUTO_DISPATCH_ON_QUEUE_ENTRY',
          user_type: 'sistema',
          user_name: 'Pendientes',
          details: `Pendiente ${chosenOrder.id} asignado automáticamente al entrar capacidad en ${zone}`,
          metadata: {
            orderId: chosenOrder.id,
            driverId: chosenDriver.id,
            triggerDriverId: driverId,
            zone
          }
        }).catch(() => {});

        return Response.json({
          success: true,
          assigned: true,
          orderId: chosenOrder.id,
          driverId: chosenDriver.id,
          zone
        });
      }

      // Carrera legítima: otro despacho pudo tomar el viaje o el móvil entre la
      // selección y el CAS. No tocamos estados; solo evitamos repetir el mismo par.
      const excluded = failedByOrder.get(chosenOrder.id) || new Set<string>();
      excluded.add(chosenDriver.id);
      failedByOrder.set(chosenOrder.id, excluded);
    }

    return Response.json({ success: true, assigned: false, reason: 'RACE_RETRY_LIMIT', zone });
  } catch (error: any) {
    console.error('dispatchPendingOnDriverQueueEntry error:', error);
    return Response.json({ success: false, error: error?.message || String(error) }, { status: 500 });
  }
});