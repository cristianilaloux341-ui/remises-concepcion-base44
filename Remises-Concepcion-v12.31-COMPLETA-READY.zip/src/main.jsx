import React from 'react'
import ReactDOM from 'react-dom/client'
import App from '@/App.jsx'
import '@/index.css'
import { Capacitor } from '@capacitor/core'

// (Limpieza de cachés y SW removida: causaba reseteos constantes de la app)

// Sync dark mode with system preference
const applyTheme = () => {
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  document.documentElement.classList.toggle('dark', prefersDark);
};
applyTheme();
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);

// Ocultamiento de consola en producción (seguridad)
if (window.location.hostname !== 'localhost') {
  console.log = () => {};
  console.info = () => {};
  console.warn = () => {};
  console.error = () => {};
  console.debug = () => {};
  console.trace = () => {};

  // Bloqueo de herramientas de desarrollo (Anti-Inspección)
  document.addEventListener('contextmenu', (e) => e.preventDefault());
  document.addEventListener('keydown', (e) => {
    if (
      e.key === 'F12' ||
      (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'i' || e.key === 'J' || e.key === 'j' || e.key === 'C' || e.key === 'c')) ||
      (e.ctrlKey && (e.key === 'U' || e.key === 'u')) ||
      (e.metaKey && e.altKey && (e.key === 'I' || e.key === 'i' || e.key === 'J' || e.key === 'j' || e.key === 'U' || e.key === 'u'))
    ) {
      e.preventDefault();
    }
  });
}

// Detección de emulador removida para evitar falsos positivos en Capacitor

// Registrar el Service Worker para PWA y push notifications (Solo en Web, bloqueado en Nativo)
try {
  if ('serviceWorker' in navigator && !Capacitor.isNativePlatform()) {
    window.addEventListener('load', () => {
      try {
        navigator.serviceWorker.register('/sw.js').catch(() => {
          // SW registration failed silently
        });
      } catch (e) {}
    });
  }
} catch (e) {}

ReactDOM.createRoot(document.getElementById('root')).render(
  <App />
)