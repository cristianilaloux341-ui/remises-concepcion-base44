import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MapPin, User, Phone, DollarSign, Loader2, Plus, X, Zap, Car, UserPlus, Wand2, Calculator } from "lucide-react";
import { detectZoneFromAddress, detectZoneFromCoords, learnZoneMapping, parseAddress, getBaseQueue } from "@/lib/dispatchLogic";
import PickupAutocomplete from "@/components/orders/PickupAutocomplete";
import AddressAutocomplete from "@/components/orders/AddressAutocomplete";
import { recordAddressUsage } from "@/hooks/useAddressSuggestions";
import { useTarifaConfig, calcularDistanciaRuta, calcularImporte } from "@/hooks/useTarifaConfig";
import { resolveActiveDriverForMobile } from "@/lib/mobileDriverResolver";

const ZONES = ["1-Puerto", "2-Plaza", "3-Columna", "4-Base", "5-Cementerio", "6-Díaz Vélez", "7-Don Bosco", "8-Monumento"];

export default function OrderForm({ order, onSubmit, isSubmitting, onCancel = () => {}, allowManualAssignment = false }) {
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        onCancel();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onCancel]);
  const [form, setForm] = useState({
    client_name: "",
    client_phone: "",
    client_id: "",
    pickup_address: "",
    dropoff_address: "",
    dropoff_addresses: [],
    zone: "",
    driver_id: "",
    driver_name: "",
    fare: "",
    notes: "",
    payment_method: "Efectivo",
    status: "pendiente",
    ...order,
  });

  const [autoAssigning, setAutoAssigning] = useState(false);
  const queryClient = useQueryClient();
  const [suggestedDriver, setSuggestedDriver] = useState(null);
  const [detectedZone, setDetectedZone] = useState(null);
  const [detectingZone, setDetectingZone] = useState(false);
  const [calculandoTarifa, setCalculandoTarifa] = useState(false);
  const [distanciaCalculada, setDistanciaCalculada] = useState(null);
  const tarifa = useTarifaConfig();
  const submitLockRef = useRef(false);
  const zoneDetectSeqRef = useRef(0);
  const zoneManualOverrideRef = useRef(false);

  // Geocodifica una dirección de texto si no tiene coords, usando Google Places
  const geocodeAddress = async (address) => {
    try {
      const sessionToken = localStorage.getItem('client_token') || sessionStorage.getItem('local_operator_token') || 'client_demo_token';
      const res = await base44.functions.invoke("geocodeRoute", { action: "autocomplete", input: address, sessionToken });
      const predictions = res.data?.predictions;
      if (!predictions || predictions.length === 0) return null;
      const details = await base44.functions.invoke("geocodeRoute", {
        action: "placedetails",
        place_id: predictions[0].place_id,
        description: predictions[0].description,
        sessionToken
      });
      if (details.data?.lat && details.data?.lng) return { lat: details.data.lat, lng: details.data.lng };
    } catch (_) {}
    return null;
  };

  // Auto-calcular tarifa cuando ambas direcciones estén completas
  useEffect(() => {
    const pickup = form.pickup_address?.trim();
    const dropoff = form.dropoff_address?.trim();
    if (!pickup || pickup.length < 4 || !dropoff || dropoff.length < 4) return;

    const timeout = setTimeout(async () => {
      setCalculandoTarifa(true);

      // Usar coords del form si están disponibles, si no geocodificar
      let origenCoords = (form.pickup_lat && form.pickup_lng) ? { lat: form.pickup_lat, lng: form.pickup_lng } : await geocodeAddress(pickup);
      let destinoCoords = (form.dropoff_lat && form.dropoff_lng) ? { lat: form.dropoff_lat, lng: form.dropoff_lng } : await geocodeAddress(dropoff);

      // Guardar coords en el form si las obtuvimos por geocodificación
      if (origenCoords || destinoCoords) {
        setForm(prev => ({
          ...prev,
          pickup_lat: origenCoords?.lat ?? prev.pickup_lat,
          pickup_lng: origenCoords?.lng ?? prev.pickup_lng,
          dropoff_lat: destinoCoords?.lat ?? prev.dropoff_lat,
          dropoff_lng: destinoCoords?.lng ?? prev.dropoff_lng,
        }));
      }

      const metros = await calcularDistanciaRuta(pickup, dropoff, origenCoords, destinoCoords);
      setCalculandoTarifa(false);
      if (metros) {
        setDistanciaCalculada(metros);
        const importe = calcularImporte(metros, tarifa);
        setForm(prev => ({
          ...prev,
          fare: importe,
          distancia_teorica_metros: metros,
          importe_estimado: importe,
          importe_real_actual: 0,
        }));
      } else {
        setDistanciaCalculada(-1);
      }
    }, 1000);
    return () => clearTimeout(timeout);
  }, [form.pickup_address, form.dropoff_address]);

  const { data: drivers = [] } = useQuery({
    queryKey: ["drivers"],
    queryFn: () => base44.entities.Driver.filter({ status: "disponible" }),
    staleTime: 10_000,
    refetchInterval: 10_000,
    refetchOnWindowFocus: true,
  });

  const availableDriverIds = [...new Set(drivers.map(d => d.id).filter(Boolean))].sort();
  const availableDriverMobileIds = [...new Set(drivers.map(d => String(d.vehicle_model || "")).filter(Boolean))].sort();
  const availableDriverMobileNumbers = [...new Set(drivers.map(d => parseInt(String(d.vehicle_model || ""), 10)).filter(Number.isFinite))].sort((a, b) => a - b);

  const { data: moviles = [] } = useQuery({
    queryKey: ["moviles_order_form", availableDriverIds.join(","), availableDriverMobileIds.join(","), availableDriverMobileNumbers.join(",")],
    queryFn: async () => {
      const clauses = [];
      if (availableDriverMobileNumbers.length) clauses.push({ numero_movil: { $in: availableDriverMobileNumbers } });
      if (availableDriverIds.length) {
        clauses.push({ driver_id: { $in: availableDriverIds } });
        clauses.push({ driver_ids: { $in: availableDriverIds } });
      }
      const [byId, fallback] = await Promise.all([
        Promise.all(availableDriverMobileIds.map(id => base44.entities.Movil.get(id).catch(() => null))),
        clauses.length ? base44.entities.Movil.filter({ $or: clauses }).catch(() => []) : Promise.resolve([])
      ]);
      return [...byId.filter(Boolean), ...fallback]
        .filter((m, i, arr) => arr.findIndex(x => x.id === m.id) === i);
    },
    enabled: drivers.length > 0,
    staleTime: 10_000,
    refetchInterval: 10_000,
    refetchOnWindowFocus: true,
  });

  const { data: clients = [] } = useQuery({
    queryKey: ["clients"],
    queryFn: () => base44.entities.Client.list(),
  });

  const { data: bases = [] } = useQuery({
    queryKey: ["bases"],
    queryFn: () => base44.entities.Base.list(),
  });

  const { data: clientAddresses = [] } = useQuery({
    queryKey: ["client_addresses"],
    queryFn: () => base44.entities.ClientAddress.list("-usage_count", 500),
    staleTime: 30_000,
  });

  const isDriverWorking = (d) => {
    if (d.status !== "disponible") return false;
    if (d.active_order_id || d.active_ride_id || d.reserved_order_id) return false;
    if (d.dispatch_status != null && d.dispatch_status !== "normal") return false;

    const mobileId = String(d.vehicle_model || "");
    const mobileNumber = parseInt(mobileId, 10);
    const driverPlate = String(d.vehicle_plate || "").replace(/\s+/g, "").toUpperCase();
    const movil = moviles?.find(m =>
      m.id === mobileId ||
      m.numero_movil === mobileNumber ||
      m.driver_id === d.id ||
      (Array.isArray(m.driver_ids) && m.driver_ids.includes(d.id)) ||
      (driverPlate && String(m.dominio || "").replace(/\s+/g, "").toUpperCase() === driverPlate)
    );

    // Sin un móvil real habilitado no existe candidato válido, aunque el Driver
    // conserve por error una base o un estado "disponible" antiguos.
    if (!movil || movil.activo === false || movil.fuera_de_servicio === true || movil.suspension_motivo) {
      return false;
    }
    return true;
  };

  const availableDrivers = drivers.filter(d => isDriverWorking(d) && d.current_base);

  // Auto-detect zone when pickup address changes.
  // Cada búsqueda lleva una secuencia: una respuesta vieja jamás puede pisar
  // la dirección/zona que el operador ya cambió mientras esperaba al backend.
  useEffect(() => {
    const requestSeq = ++zoneDetectSeqRef.current;
    if (!form.pickup_address || form.pickup_address.length < 3) {
      setDetectedZone(null);
      setDetectingZone(false);
      return;
    }

    const timeout = setTimeout(async () => {
      const isCurrent = () => zoneDetectSeqRef.current === requestSeq;
      setDetectingZone(true);
      let zone = null;
      
      // Si la sugerencia trae coordenadas exactas (Geoapify/OSM), el polígono manda.
      // Esto evita que una memoria vieja de calle completa asigne una zona incorrecta
      // cuando esa misma calle atraviesa más de una zona.
      const selectedCoords = (form.pickup_lat && form.pickup_lng)
        ? { lat: form.pickup_lat, lng: form.pickup_lng }
        : null;

      if (selectedCoords) {
        zone = await detectZoneFromCoords(selectedCoords.lat, selectedCoords.lng);
        if (!isCurrent()) return;
      }

      // Sin coordenadas seleccionadas, usar primero la memoria local para no hacer
      // consultas externas innecesarias en direcciones ya conocidas.
      if (!zone && !selectedCoords) {
        zone = await detectZoneFromAddress(form.pickup_address);
        if (!isCurrent()) return;
      }

      // Último recurso: geocodificar el texto y resolver por el polígono real.
      if (!zone && !selectedCoords) {
        const coords = await geocodeAddress(form.pickup_address);
        if (!isCurrent()) return;
        if (coords) {
          zone = await detectZoneFromCoords(coords.lat, coords.lng);
          if (!isCurrent()) return;
          setForm(prev => ({ ...prev, pickup_lat: coords.lat, pickup_lng: coords.lng }));
        }
      }

      if (!isCurrent() || zoneManualOverrideRef.current) return;
      setDetectingZone(false);
      if (zone) {
        setDetectedZone(zone);
        setForm(prev => ({ ...prev, zone }));
      } else {
        setDetectedZone(null);
      }
    }, 600);

    return () => {
      clearTimeout(timeout);
      if (zoneDetectSeqRef.current === requestSeq) zoneDetectSeqRef.current += 1;
    };
  }, [form.pickup_address, form.pickup_lat, form.pickup_lng]);

  // Sugerir únicamente el primero de la cola de la base exacta del pasaje.
  // La resolución es sincrónica para que nunca quede visible una sugerencia de la zona anterior.
  useEffect(() => {
    if (!form.pickup_address || !form.zone) {
      setSuggestedDriver(null);
      return;
    }
    const zoneQueue = getBaseQueue(availableDrivers, form.zone);
    setSuggestedDriver(zoneQueue[0] || null);

    // Si cambió la zona después de una sugerencia/selección, borrar el móvil anterior.
    // Así el formulario nunca arrastra un chofer perteneciente a otra base.
    setForm(prev => {
      if (!prev.driver_id) return prev;
      const selected = drivers.find(d => d.id === prev.driver_id);
      if (selected?.current_base === prev.zone) return prev;
      return { ...prev, driver_id: "", driver_name: "", status: "pendiente" };
    });
  }, [form.zone, form.pickup_address, drivers, moviles]);

  const handleAddressClientSelect = (clientData) => {
    // Force unconditional update — use the exact row's data (identified by addressId)
    setForm(prev => ({
      ...prev,
      client_id: clientData.client_id,
      client_name: clientData.client_name,
      client_phone: clientData.client_phone,
    }));
  };

  const [manualDriverInput, setManualDriverInput] = useState("");

  useEffect(() => {
    if (order?.driver_id && order?.driver_name && !manualDriverInput) {
      setManualDriverInput(order.driver_name);
    }
  }, [order]);

  const handleChange = (field, value) => {
    // Si el operador corrige la zona manualmente, ninguna detección que estaba
    // en vuelo puede volver a sobreescribir esa decisión.
    if (field === "zone") {
      zoneManualOverrideRef.current = true;
      zoneDetectSeqRef.current += 1;
      setDetectingZone(false);
      setDetectedZone(null);
    }
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const handleDriverChange = (driverId) => {
    if (driverId === "none" || !driverId) {
      setForm(prev => ({ ...prev, driver_id: "", driver_name: "", status: "pendiente" }));
      setManualDriverInput("");
      return;
    }
    const driver = drivers.find(d => d.id === driverId);
    if (driver) {
      setForm(prev => ({ ...prev, driver_id: driverId, driver_name: driver.name, status: "ofrecido" }));
      setManualDriverInput(driver.name);
    }
  };

  const handleAutoAssign = async () => {
    setAutoAssigning(true);
    const driver = form.zone ? (getBaseQueue(availableDrivers, form.zone)[0] || null) : null;
    if (driver) {
      setForm(prev => ({ ...prev, driver_id: driver.id, driver_name: driver.name, status: "ofrecido" }));
      setSuggestedDriver(driver);
    } else {
      setSuggestedDriver(null);
      setForm(prev => ({ ...prev, driver_id: "", driver_name: "", status: "pendiente" }));
    }
    setAutoAssigning(false);
  };

  const addDestination = () => {
    setForm(prev => ({ ...prev, dropoff_addresses: [...(prev.dropoff_addresses || []), ""] }));
  };

  const updateDestination = (idx, value) => {
    setForm(prev => {
      const arr = [...(prev.dropoff_addresses || [])];
      arr[idx] = value;
      return { ...prev, dropoff_addresses: arr };
    });
  };

  const removeDestination = (idx) => {
    setForm(prev => ({
      ...prev,
      dropoff_addresses: (prev.dropoff_addresses || []).filter((_, i) => i !== idx),
    }));
  };

  const handleCalcularTarifa = async () => {
    if (!form.pickup_address || !form.dropoff_address) return;
    setCalculandoTarifa(true);
    setDistanciaCalculada(null);
    let origenCoords = (form.pickup_lat && form.pickup_lng) ? { lat: form.pickup_lat, lng: form.pickup_lng } : await geocodeAddress(form.pickup_address.trim());
    let destinoCoords = (form.dropoff_lat && form.dropoff_lng) ? { lat: form.dropoff_lat, lng: form.dropoff_lng } : await geocodeAddress(form.dropoff_address.trim());
    const metros = await calcularDistanciaRuta(form.pickup_address, form.dropoff_address, origenCoords, destinoCoords);
    setCalculandoTarifa(false);
    if (metros) {
      setDistanciaCalculada(metros);
      const importe = calcularImporte(metros, tarifa);
      setForm(prev => ({
        ...prev,
        fare: importe,
        distancia_teorica_metros: metros,
        importe_estimado: importe,
        importe_real_actual: importe,
      }));
    } else {
      setDistanciaCalculada(-1);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (submitLockRef.current || isSubmitting) return; // Prevent double submit
    submitLockRef.current = true;
    setTimeout(() => { submitLockRef.current = false; }, 2000);
    const data = { ...form };
    if (data.fare && String(data.fare).trim() !== "") {
      data.fare = Number(data.fare);
      data.importe_estimado = data.fare;
      // La cotización no es el taxímetro real. El importe real comienza al iniciar el viaje.
      data.importe_real_actual = 0;
    } else {
      delete data.fare;
      data.importe_estimado = undefined;
      data.importe_real_actual = undefined;
    }
    
    if (distanciaCalculada && distanciaCalculada > 0) {
      data.distancia_teorica_metros = distanciaCalculada;
    } else if (data.dropoff_address && !data.distancia_teorica_metros && data.fare) {
      // Precio/cotización manual no debe falsificar la distancia del viaje.
      data.distancia_teorica_metros = 0;
    } else if (!data.distancia_teorica_metros) {
      data.distancia_teorica_metros = 0; // Si no hay precio fijo ni distancia, que el taxímetro cuente desde cero.
    }
    
    data.segundos_espera_acumulados = 0;
    data.segundos_tolerancia_espera_usados = 0;
    data.metros_taximetro = 0;
    data.taximetro_iniciado = false;

    // El operador común nunca puede inyectar una asignación manual, aunque llegue un dato viejo.
    if (!allowManualAssignment) {
      delete data.driver_id;
      delete data.driver_name;
      delete data._resolved_mobile_id;
      data.status = "pendiente";
    }

    // La selección visual nunca puede saltar la validación del estado real del chofer.
    if (data.driver_id) {
      const selectedDriver = drivers.find(d => d.id === data.driver_id);
      if (!selectedDriver || selectedDriver.status !== "disponible") {
        alert(`El móvil ${data.driver_name || manualDriverInput || ""} está fuera de servicio u ocupado. El pasaje no fue asignado.`);
        return;
      }
      // Si fue elegido por Central, puede ser una excepción manual de emergencia.
      // La barrera de zona estricta continúa vigente para todo despacho automático.
      data.driver_name = selectedDriver.name;
      data.status = "ofrecido";
    }

    if (!data.driver_id && manualDriverInput) {
      const inputTrimmed = manualDriverInput.trim();
      const resolved = resolveActiveDriverForMobile(inputTrimmed, drivers, moviles);
      if (!resolved.driver) {
        alert(resolved.error);
        return;
      }

      data.driver_id = resolved.driver.id;
      data.driver_name = resolved.driver.name;
      data._resolved_mobile_id = resolved.mobile?.id || null;
      data.status = "ofrecido";
    } else if (!data.driver_id) {
      delete data.driver_id; 
      delete data.driver_name;
    }

    // Auto-save/update client in database
    if (data.client_name?.trim()) {
      const existing = clients.find(c =>
        (data.client_id && c.id === data.client_id) ||
        (data.client_phone && c.phone === data.client_phone?.trim()) ||
        c.name?.toLowerCase() === data.client_name.trim().toLowerCase()
      );

      if (existing) {
        // Update phone or pickup address if changed
        const updates = {};
        if (data.client_phone && !existing.phone) updates.phone = data.client_phone.trim();
        if (data.pickup_address && !existing.pickup_address) updates.pickup_address = data.pickup_address;
        if (Object.keys(updates).length > 0) {
          await base44.entities.Client.update(existing.id, updates);
        }
        data.client_id = existing.id;
      } else if (!data.client_id) {
        // New client — create automatically
        const newClient = await base44.entities.Client.create({
          name: data.client_name.trim(),
          phone: data.client_phone?.trim() || undefined,
          pickup_address: data.pickup_address || undefined,
        });
        data.client_id = newClient.id;
      }
      queryClient.invalidateQueries(["clients"]);
    }

    if (!data.client_id) delete data.client_id;

    // Record address usage for autocomplete learning
    if (data.pickup_address) recordAddressUsage(data.pickup_address, queryClient);
    if (data.dropoff_address) recordAddressUsage(data.dropoff_address, queryClient);
    (data.dropoff_addresses || []).forEach(a => a && recordAddressUsage(a, queryClient));

    // Learn zone mapping from address+zone for future auto-detection
    if (data.zone && data.pickup_address) {
      learnZoneMapping(data.pickup_address, data.zone).catch(() => {});
    }

    // Save/update ClientAddress for all addresses linked to this client
    if (data.client_id) {
      const allAddresses = [
        data.pickup_address,
        data.dropoff_address,
        ...(data.dropoff_addresses || []),
      ].filter(a => a && a.trim().length >= 3);

      for (const addr of allAddresses) {
        const addrNorm = addr.trim().toLowerCase();
        const existingCA = clientAddresses.find(ca =>
          ca.client_id === data.client_id &&
          (ca.full_address || "").trim().toLowerCase() === addrNorm
        );
        if (existingCA) {
          base44.entities.ClientAddress.update(existingCA.id, {
            usage_count: (existingCA.usage_count || 0) + 1,
            last_used: new Date().toISOString(),
            client_name: data.client_name,
            client_phone: data.client_phone || "",
          }).catch(() => {});
        } else {
          const parsed = parseAddress(addr);
          base44.entities.ClientAddress.create({
            client_id: data.client_id,
            client_name: data.client_name,
            client_phone: data.client_phone || "",
            street: parsed.street || addr,
            height: parsed.number ? String(parsed.number) : "",
            full_address: addr,
            usage_count: 1,
            last_used: new Date().toISOString(),
          }).catch(() => {});
        }
      }
      queryClient.invalidateQueries({ queryKey: ["client_addresses"] });
    }

    onSubmit(data);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
            <MapPin className="w-4 h-4 text-primary" />
          </div>
          {order ? "Editar Viaje" : "Nuevo Viaje"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-5">

          {/* ── DIRECCIÓN DE ORIGEN ── */}
          <div className="p-4 rounded-xl bg-muted/40 border space-y-3">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5" /> Dirección de Origen
            </p>
            <div className="space-y-1.5">
              <Label>Recogida</Label>
              <PickupAutocomplete
                value={form.pickup_address}
                onChange={(v, coords) => {
                  zoneManualOverrideRef.current = false;
                  setForm(prev => ({ 
                    ...prev, 
                    pickup_address: v, 
                    pickup_lat: coords !== undefined ? (coords?.lat || null) : null, 
                    pickup_lng: coords !== undefined ? (coords?.lng || null) : null 
                  }));
                }}
                onClientSelect={handleAddressClientSelect}
                required
                autoFocus
              />
            </div>
            {/* Zona */}
            <div className="space-y-1.5">
              <Label className="flex items-center gap-2">
                Zona
                {detectingZone && <Loader2 className="w-3 h-3 animate-spin text-muted-foreground" />}
                {detectedZone && detectedZone === form.zone && (
                  <span className="text-xs text-green-600 flex items-center gap-1 font-normal">
                    <Wand2 className="w-3 h-3" /> Detectada automáticamente
                  </span>
                )}
                {detectedZone && detectedZone !== form.zone && form.zone && (
                  <button type="button" className="text-xs text-amber-600 underline font-normal flex items-center gap-1"
                    onClick={() => handleChange("zone", detectedZone)}>
                    <Wand2 className="w-3 h-3" /> Sugerida: {detectedZone}
                  </button>
                )}
                {!form.zone && !detectedZone && !detectingZone && form.pickup_address?.length > 2 && (
                  <span className="text-xs text-amber-600 font-normal">Selección manual requerida</span>
                )}
              </Label>
              <Select value={form.zone || ""} onValueChange={(v) => handleChange("zone", v)}>
                <SelectTrigger className={!form.zone ? "border-amber-300" : ""}>
                  <SelectValue placeholder="Seleccionar zona..." />
                </SelectTrigger>
                <SelectContent>
                  {ZONES.map(z => <SelectItem key={z} value={z}>{z}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* ── CLIENTE ── */}
          <div className="p-4 rounded-xl bg-muted/40 border space-y-3">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-1.5">
              <User className="w-3.5 h-3.5" /> Cliente
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="client_name">Nombre</Label>
                <div className="relative">
                  <UserPlus className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="client_name"
                    className="pl-9"
                    placeholder="Nombre del cliente"
                    value={form.client_name}
                    onChange={(e) => handleChange("client_name", e.target.value)}
                    required
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="client_phone">Teléfono</Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="client_phone"
                    className="pl-9"
                    placeholder="3462-123456"
                    value={form.client_phone}
                    onChange={(e) => handleChange("client_phone", e.target.value)}
                  />
                </div>
              </div>
            </div>
            {form.client_id ? (
              <p className="text-xs text-green-600 flex items-center gap-1">
                <User className="w-3 h-3" /> Cliente vinculado de la base de datos
              </p>
            ) : form.client_name?.trim() ? (
              <p className="text-xs text-blue-600 flex items-center gap-1">
                <UserPlus className="w-3 h-3" /> Se guardará como nuevo cliente al confirmar
              </p>
            ) : null}
          </div>

          {/* ── DESTINOS ── */}
          <div className="p-4 rounded-xl bg-muted/40 border space-y-3">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5" /> Destinos
            </p>
            <div className="space-y-1.5">
              <Label>Destino Principal</Label>
              <AddressAutocomplete
                value={form.dropoff_address}
                onChange={(v, coords) => setForm(prev => ({ 
                  ...prev, 
                  dropoff_address: v, 
                  dropoff_lat: coords !== undefined ? (coords?.lat || null) : null, 
                  dropoff_lng: coords !== undefined ? (coords?.lng || null) : null 
                }))}
                placeholder="Calle y número de destino"
                icon={<MapPin className="w-4 h-4 text-red-500" />}
              />
            </div>
            {(form.dropoff_addresses || []).map((addr, idx) => (
              <div key={idx} className="flex gap-2 items-center">
                <div className="flex-1">
                  <AddressAutocomplete
                    value={addr}
                    onChange={(v) => updateDestination(idx, v)}
                    placeholder={`Parada ${idx + 2}`}
                    icon={<MapPin className="w-4 h-4 text-orange-400" />}
                  />
                </div>
                <Button type="button" size="icon" variant="ghost" className="text-red-400 hover:text-red-600 shrink-0"
                  onClick={() => removeDestination(idx)}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ))}
            <Button type="button" variant="outline" size="sm" className="gap-1.5 rounded-lg" onClick={addDestination}>
              <Plus className="w-3.5 h-3.5" /> Agregar parada
            </Button>
          </div>

          {/* ── ASIGNACIÓN ── */}
          {allowManualAssignment ? (
          <div className="p-4 rounded-xl bg-muted/40 border space-y-3">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-1.5">
              <Car className="w-3.5 h-3.5" /> Asignación de Móvil
            </p>

            {/* Cola de móviles en la zona seleccionada */}
            {form.zone && (
              <div className="bg-white rounded-xl border p-3">
                <p className="text-xs font-bold text-slate-500 mb-2">Móviles en cola para {form.zone}:</p>
                <div className="flex flex-wrap gap-2">
                  {getBaseQueue(availableDrivers, form.zone).map((d, i) => (
                    <Badge 
                      key={d.id} 
                      variant="outline"
                      className={`cursor-pointer px-2 py-1 text-xs transition-colors ${form.driver_id === d.id ? 'bg-green-500 text-white border-green-600 hover:bg-green-600' : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border-slate-200'}`}
                      onClick={() => handleDriverChange(d.id)}
                    >
                      {i + 1}. {d.name}
                    </Badge>
                  ))}
                  {getBaseQueue(availableDrivers, form.zone).length === 0 && (
                    <span className="text-xs text-amber-600">No hay móviles en esta base en este momento.</span>
                  )}
                </div>
              </div>
            )}

            {/* Sugerencia automática */}
            {suggestedDriver && !form.driver_id && (
              <div className="flex items-center gap-3 p-3 bg-amber-50 border border-amber-200 rounded-xl">
                <Zap className="w-4 h-4 text-amber-500 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold">{suggestedDriver.name}</p>
                  <p className="text-xs text-muted-foreground font-mono">{suggestedDriver.vehicle_plate} · {suggestedDriver.current_base}</p>
                </div>
                <Button type="button" size="sm" className="gap-1.5 rounded-lg shrink-0 bg-amber-500 hover:bg-amber-600"
                  onClick={handleAutoAssign} disabled={autoAssigning}>
                  {autoAssigning ? <Loader2 className="w-3 h-3 animate-spin" /> : <Zap className="w-3 h-3" />}
                  Asignar
                </Button>
              </div>
            )}

            {form.driver_id && (
              <div className="flex items-center gap-2 p-2 bg-green-50 border border-green-200 rounded-xl">
                <Car className="w-4 h-4 text-green-600" />
                <p className="text-sm font-semibold text-green-700 flex-1">{form.driver_name}</p>
                <Badge className="bg-green-100 text-green-700 border-0 text-xs">asignado</Badge>
                <Button type="button" size="icon" variant="ghost" className="h-7 w-7 text-red-400"
                  onClick={() => handleChange("driver_id", "")}>
                  <X className="w-3 h-3" />
                </Button>
              </div>
            )}

            <div className="flex gap-2">
              <input 
                className="flex-1 h-9 text-base font-extrabold text-slate-900 rounded-lg border-2 border-slate-400 px-3 bg-white placeholder:text-slate-500 placeholder:font-normal"
                style={{ color: "#000000", backgroundColor: "#ffffff" }}
                placeholder="Emergencia: Nº de móvil..."
                value={manualDriverInput}
                onChange={(e) => {
                  setManualDriverInput(e.target.value);
                  setForm(prev => ({ ...prev, driver_id: "" })); // Clear actual ID to trigger auto-creation on submit
                }}
              />
              <Button type="button" variant="outline" className="gap-1.5 rounded-lg shrink-0"
                onClick={handleAutoAssign} disabled={autoAssigning || !form.pickup_address}>
                {autoAssigning ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5" />}
                Auto
              </Button>
            </div>

            {availableDrivers.length === 0 && (
              <p className="text-xs text-amber-600">Sin móviles disponibles en base</p>
            )}
          </div>
          ) : (
            <div className="p-4 rounded-xl bg-blue-50 border border-blue-200 space-y-1">
              <p className="text-sm font-semibold text-blue-900">Despacho automático por zona</p>
              <p className="text-xs text-blue-700">
                Se ofrecerá respetando el orden de móviles de {form.zone || "la zona del pasaje"}.
                Si la cola se agota, quedará en Pendientes para que lo tome un chofer.
              </p>
            </div>
          )}

          {/* ── TARIFA Y NOTAS ── */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="fare">Tarifa ($)</Label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="fare"
                    className="pl-9"
                    type="number"
                    placeholder="0"
                    value={form.fare}
                    onChange={(e) => handleChange("fare", e.target.value)}
                  />
                </div>
                <Button
                  type="button"
                  variant="outline"
                  className="gap-1.5 shrink-0 text-xs"
                  disabled={!form.pickup_address || !form.dropoff_address || calculandoTarifa}
                  onClick={handleCalcularTarifa}
                  title="Calcula la tarifa basada en la distancia real de ruta"
                >
                  {calculandoTarifa ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Calculator className="w-3.5 h-3.5" />}
                  Calcular
                </Button>
              </div>
              {distanciaCalculada > 0 && (
                <p className="text-xs text-green-600">
                  📍 {(distanciaCalculada / 1000).toFixed(1)} km · Bandera ${tarifa.bajada_bandera} + $100 cada 85 m {tarifa.es_nocturna ? "🌙 nocturna" : ""}
                </p>
              )}
              {distanciaCalculada === -1 && (
                <p className="text-xs text-amber-600">
                  ⚠ No se pudo calcular la distancia — ingresá el monto manualmente
                </p>
              )}
              {calculandoTarifa && (
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <Loader2 className="w-3 h-3 animate-spin" /> Calculando tarifa...
                </p>
              )}
            </div>
            <div className="space-y-1.5">
              <Label>Método de Pago</Label>
              <Select value={form.payment_method || "Efectivo"} onValueChange={(v) => handleChange("payment_method", v)}>
                <SelectTrigger>
                  <SelectValue placeholder="Efectivo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Efectivo">Efectivo</SelectItem>
                  <SelectItem value="Transferencia">Transferencia</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5 md:col-span-2">
              <Label htmlFor="notes">Notas</Label>
              <Input
                id="notes"
                placeholder="Observaciones..."
                value={form.notes}
                onChange={(e) => handleChange("notes", e.target.value)}
              />
            </div>
          </div>

          <Button type="submit" className="w-full h-11 rounded-xl" disabled={isSubmitting}>
            {isSubmitting ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Guardando...</>
            ) : order ? "Actualizar Viaje" : "Crear Viaje"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}