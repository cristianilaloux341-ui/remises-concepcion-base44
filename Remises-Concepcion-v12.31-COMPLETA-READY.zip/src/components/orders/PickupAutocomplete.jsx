import { useState, useRef, useEffect, useMemo } from "react";
import { Input } from "@/components/ui/input";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { MapPin, User, Clock, Globe } from "lucide-react";
import { cn } from "@/lib/utils";
import { useGooglePlaces } from "@/hooks/useGooglePlaces";
import { useAddressSuggestions } from "@/hooks/useAddressSuggestions";

const normalize = (s) =>
  (s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();

export default function PickupAutocomplete({ value, onChange, onClientSelect, placeholder, className, required, restrictToClient, autoFocus }) {
  const [open, setOpen] = useState(false);
  const [inputValue, setInputValue] = useState(value || "");
  const containerRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => { setInputValue(value || ""); }, [value]);

  // Click outside
  useEffect(() => {
    const h = (e) => { if (!containerRef.current?.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  const normalizedInput = normalize(inputValue);
  // Buscar por la parte de calle para tolerar variantes guardadas como
  // "Ratto Dr. 917" frente a lo escrito "Ratto 917".
  const searchTerm = inputValue.trim();
  const streetSearchTerm = searchTerm.split(/\s+\d/)[0].trim() || searchTerm;

  const { data: clientAddresses = [] } = useQuery({
    queryKey: ["client_addresses_search", restrictToClient || "all", normalizedInput],
    queryFn: () => {
      if (restrictToClient) {
        return base44.entities.ClientAddress.filter({ client_id: restrictToClient }, "-usage_count", 500);
      }
      if (searchTerm.length < 3) return [];
      // Buscar en servidor: listar solo los 500 más usados hacía desaparecer
      // direcciones guardadas que quedaban fuera de ese corte.
      return base44.entities.ClientAddress.filter({
        full_address: { $regex: streetSearchTerm, $options: "i" }
      }, "-usage_count", 100);
    },
    enabled: !!restrictToClient || searchTerm.length >= 3,
    staleTime: 30_000,
  });

  const osmAndHistory = useAddressSuggestions(inputValue);
  const { predictions, getPlaceDetails } = useGooglePlaces(inputValue);

  const suggestions = useMemo(() => {
    if (!inputValue || inputValue.length < 3) return [];
    const norm = normalize(inputValue);

    const seenClientAddresses = new Set();
    const queryParts = norm.split(/\s+/).filter(Boolean);
    const clientResults = clientAddresses
      .filter((ca) => {
        const address = normalize(ca.full_address);
        return queryParts.every(part => address.includes(part));
      })
      .sort((a, b) => {
        const aa = normalize(a.full_address);
        const bb = normalize(b.full_address);
        const rankA = aa === norm ? 0 : queryParts.every(part => aa.includes(part)) ? 1 : 2;
        const rankB = bb === norm ? 0 : queryParts.every(part => bb.includes(part)) ? 1 : 2;
        return rankA - rankB || (b.usage_count || 0) - (a.usage_count || 0);
      })
      .filter((ca) => {
        const key = normalize(ca.full_address);
        if (seenClientAddresses.has(key)) return false;
        seenClientAddresses.add(key);
        return true;
      })
      .map((ca) => ({ ...ca, type: "client" }))
      .slice(0, 5);

    const clientAddressNorms = new Set(clientResults.map((r) => normalize(r.full_address)));
    
    const historyResults = osmAndHistory
      .filter(x => x.source === "history" && !clientAddressNorms.has(normalize(x.address)))
      .map(x => ({ ...x, type: "history", full_address: x.address }))
      .slice(0, 3);

    const localNorms = new Set([...clientResults, ...historyResults].map(r => normalize(r.full_address)));
    
    const osmResults = osmAndHistory
      .filter(x => x.source === "osm" && !localNorms.has(normalize(x.address)))
      .map(x => ({ ...x, type: "osm", full_address: x.address }))
      .slice(0, 4);

    const allLocalNorms = new Set([...clientResults, ...historyResults, ...osmResults].map(r => normalize(r.full_address)));
    
    const geoapifyItems = predictions
      .filter(p => !allLocalNorms.has(normalize(p.description)))
      .slice(0, 4)
      .map((p) => ({
        id: p.place_id,
        full_address: p.description,
        place_id: p.place_id,
        type: "geoapify",
        usage_count: 0,
      }));

    return [...clientResults, ...historyResults, ...osmResults, ...geoapifyItems];
  }, [inputValue, clientAddresses, osmAndHistory, predictions]);

  const handleChange = (e) => {
    const val = e.target.value;
    setInputValue(val);
    onChange(val);
    setOpen(val.length >= 3);
  };

  const handleSelect = async (s) => {
    setInputValue(s.full_address);
    setOpen(false);

    let coords = s.lat && s.lng ? { lat: s.lat, lng: s.lng } : null;

    // Para resultados externos de Geoapify, recuperar las coordenadas exactas.
    if (s.type === "geoapify" && s.place_id) {
      try {
        const details = await getPlaceDetails(s.place_id);
        if (details?.lat && details?.lng) {
          coords = { lat: details.lat, lng: details.lng };
        }
      } catch (_) {}
    }

    onChange(s.full_address, coords);

    if (s.type === "client") {
      onClientSelect?.({
        addressId: s.id,
        client_id: s.client_id,
        client_name: s.client_name ?? "",
        client_phone: s.client_phone ?? "",
        floor_apt: s.floor_apt ?? "",
      });
    }
  };

  return (
    <div ref={containerRef} className="relative">
      <div className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none z-10">
        <div className="w-3 h-3 rounded-full bg-green-500" />
      </div>
      <Input
        id="pickup-address-input"
        ref={inputRef}
        className={cn("pl-8", className)}
        placeholder={placeholder || "Dirección o nombre del cliente..."}
        value={inputValue}
        onChange={handleChange}
        onFocus={() => inputValue.length >= 3 && setOpen(true)}
        required={required}
        autoComplete="off"
        autoFocus={autoFocus}
      />
      {open && suggestions.length > 0 && (
        <div className="absolute z-50 top-full mt-1 w-full bg-popover border rounded-xl shadow-lg overflow-hidden max-h-72 overflow-y-auto">
          {suggestions.map((s) => (
            <button
              key={`${s.type}-${s.id}`}
              type="button"
              className="w-full px-4 py-2.5 text-left hover:bg-muted flex items-center gap-3 transition-colors border-b last:border-0 border-border/50"
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => handleSelect(s)}
            >
              {s.type === "geoapify" || s.type === "osm"
                ? <Globe className={cn("w-4 h-4 shrink-0", s.type === "osm" ? "text-green-500" : "text-blue-400")} />
                : <MapPin className="w-4 h-4 text-muted-foreground shrink-0" />
              }
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{s.full_address}</p>
                {s.type === "client" && !restrictToClient && (
                  <p className="text-xs text-muted-foreground truncate">
                    <User className="w-3 h-3 inline mr-1" />
                    {s.client_name || "(sin nombre)"}
                    {s.client_phone ? ` · ${s.client_phone}` : ""}
                    {s.floor_apt ? ` · Piso ${s.floor_apt}` : ""}
                  </p>
                )}
                {s.type === "client" && restrictToClient && s.floor_apt && (
                  <p className="text-xs text-muted-foreground truncate">
                    Piso/Depto: {s.floor_apt}
                  </p>
                )}
              </div>
              {s.type === "geoapify" && (
                <span className="text-xs text-blue-400 shrink-0">Geoapify</span>
              )}
              {s.type === "osm" && (
                <span className="text-xs text-green-600 font-medium shrink-0">OSM</span>
              )}
              {s.type !== "geoapify" && s.type !== "osm" && (s.usage_count || 0) > 1 && (!restrictToClient || s.type === "client") && (
                <span className="flex items-center gap-1 text-xs text-muted-foreground shrink-0">
                  <Clock className="w-3 h-3" />
                  {s.usage_count}x
                </span>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}