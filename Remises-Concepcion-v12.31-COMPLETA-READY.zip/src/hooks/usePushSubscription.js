import { useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Capacitor } from "@capacitor/core";
import { PushNotifications } from "@capacitor/push-notifications";

/**
 * Registra la push subscription del navegador o nativa (FCM) para este chofer.
 */
export function usePushSubscription(driverId) {
  const subscribedRef = useRef(false);

  useEffect(() => {
    if (!driverId || subscribedRef.current) return;

    // Log the initiation of the push subscription attempt
    base44.entities.AuditLog.create({
      action: 'push_debug',
      user_type: 'sistema',
      user_name: 'Chofer ' + driverId,
      details: 'Iniciando usePushSubscription. isNative: ' + Capacitor.isNativePlatform()
    }).catch(()=>{});

    let cancelled = false;
    let registrationHandle = null;
    let registrationErrorHandle = null;

    async function registerNative() {
      try {
        let permStatus = await PushNotifications.checkPermissions();
        if (permStatus.receive === 'prompt') {
          permStatus = await PushNotifications.requestPermissions();
        }
        if (permStatus.receive !== 'granted') {
          await base44.entities.AuditLog.create({
            action: 'push_error',
            user_type: 'sistema',
            user_name: 'Chofer ' + driverId,
            details: 'Push Nativo sin permiso: ' + permStatus.receive
          }).catch(()=>{});
          return;
        }

        // IMPORTANTE: no usar removeAllListeners() acá. DriverApp mantiene sus propios
        // listeners de pushNotificationReceived / pushNotificationActionPerformed;
        // borrarlos deja a la WebView sin enterarse de viajes que Android sí recibió.
        registrationHandle = await PushNotifications.addListener('registration', async (token) => {
          // Quitamos la validación de 'cancelled' porque en Android a veces la pantalla
          // recarga muy rápido y mata el proceso justo cuando llega el token de Google.
          
          await base44.entities.AuditLog.create({
            action: 'push_debug',
            user_type: 'sistema',
            user_name: 'Chofer ' + driverId,
            details: 'TOKEN RECIBIDO CORRECTAMENTE: ' + token.value.substring(0, 10) + '...'
          }).catch(()=>{});

          await base44.functions.invoke("sendPushNotification", {
            action: "subscribe_fcm",
            driverId,
            token: token.value,
            sessionToken: localStorage.getItem("session_token")
          });
          subscribedRef.current = true;
        });

        registrationErrorHandle = await PushNotifications.addListener('registrationError', (error) => {
          console.error('Error al registrar FCM: ', error);
          base44.entities.AuditLog.create({
            action: 'push_error',
            user_type: 'sistema',
            user_name: 'Chofer ' + driverId,
            details: 'FCM Reg Error: ' + (error.error || JSON.stringify(error))
          }).catch(()=>{});
        });

        // Registrar SIEMPRE DESPUÉS de haber puesto los listeners
        await PushNotifications.register();
        await base44.entities.AuditLog.create({
          action: 'push_debug',
          user_type: 'sistema',
          user_name: 'Chofer ' + driverId,
          details: 'PushNotifications.register() ejecutado'
        }).catch(()=>{});
      } catch (e) {
        console.error("Error en Push Nativo", e);
        base44.entities.AuditLog.create({
          action: 'push_error',
          user_type: 'sistema',
          user_name: 'Chofer ' + driverId,
          details: 'Error catch Push Nativo: ' + e.message
        }).catch(()=>{});
      }
    }

    async function registerWeb() {
      try {
        if (!("serviceWorker" in navigator) || !("PushManager" in window)) return;
      } catch (e) { return; }
      try {
        // Obtener VAPID public key del backend
        const res = await base44.functions.invoke("sendPushNotification", {
          action: "vapid_public_key",
        });
        const vapidPublicKey = res?.data?.publicKey;
        if (!vapidPublicKey || cancelled) return;

        const reg = await navigator.serviceWorker.ready;

        // Verificar si ya hay una suscripción activa
        let sub = await reg.pushManager.getSubscription();
        
        // FORZAR RENOVACIÓN: Google a veces invalida la suscripción en segundo plano sin avisar.
        // También soluciona cuando cambian las claves VAPID en el servidor.
        if (sub) {
          try {
            await sub.unsubscribe();
          } catch (e) {
            console.warn("Error al desuscribir la vieja key", e);
          }
          sub = null;
        }

        // Suscribir nuevamente de cero si el permiso ya fue concedido
        if (!sub && ("Notification" in window) && Notification.permission === "granted") {
          sub = await reg.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: urlBase64ToUint8Array(vapidPublicKey),
          });
        }

        if (!sub) return; // Si no hay suscripción (y no tenemos permiso), salimos

        if (cancelled) return;

        // Registrar en el backend
        await base44.functions.invoke("sendPushNotification", {
          action: "subscribe",
          driverId,
          subscription: sub.toJSON(),
          sessionToken: localStorage.getItem("session_token")
        });

        subscribedRef.current = true;
      } catch (err) {
        console.warn("[Push] No se pudo registrar:", err?.message || err);
        base44.entities.AuditLog.create({
          action: 'push_error',
          user_type: 'sistema',
          user_name: 'Chofer ' + driverId,
          details: 'Web Push Error: ' + err.message
        }).catch(()=>{});
      }
    }

    if (Capacitor.isNativePlatform()) {
      base44.entities.AuditLog.create({ action: 'push_debug', user_type: 'sistema', user_name: 'Chofer ' + driverId, details: 'Llamando registerNative()' }).catch(()=>{});
      registerNative();
    } else {
      base44.entities.AuditLog.create({ action: 'push_debug', user_type: 'sistema', user_name: 'Chofer ' + driverId, details: 'Llamando registerWeb()' }).catch(()=>{});
      registerWeb();
    }

    return () => {
      cancelled = true;
      try { registrationHandle?.remove?.(); } catch (_) {}
      try { registrationErrorHandle?.remove?.(); } catch (_) {}
    };
  }, [driverId]);
}

// Convierte la clave VAPID Base64URL a Uint8Array (requerido por pushManager.subscribe)
function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) outputArray[i] = rawData.charCodeAt(i);
  return outputArray;
}