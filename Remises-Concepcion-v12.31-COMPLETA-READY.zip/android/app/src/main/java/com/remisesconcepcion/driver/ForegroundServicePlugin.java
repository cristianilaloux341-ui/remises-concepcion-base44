package com.remisesconcepcion.driver;

import android.content.Intent;
import android.os.Build;
import android.util.Log;
import android.net.Uri;
import android.provider.Settings;
import android.os.PowerManager;
import android.content.Context;
import androidx.core.content.ContextCompat;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "ForegroundService")
public class ForegroundServicePlugin extends Plugin {

    @PluginMethod
    public void markRideResolved(PluginCall call) {
        String orderId = call.getString("orderId");
        Integer attempt = call.getInt("assignmentAttempt", 1);
        String resolution = call.getString("resolutionType", "UNKNOWN");

        if (orderId == null || orderId.trim().isEmpty()) {
            call.reject("orderId cannot be empty");
            return;
        }
        if (attempt < 1) {
            call.reject("assignmentAttempt must be >= 1");
            return;
        }
        if (!"ACCEPTED".equals(resolution) && !"REJECTED".equals(resolution) && !"CANCELLED".equals(resolution) && !"EXPIRED".equals(resolution)) {
            call.reject("Invalid resolutionType: " + resolution);
            return;
        }

        boolean success = RideStateManager.markResolved(getContext(), orderId, attempt, resolution);
        if (success) {
            Log.e("PushDiagnostic", "RideStateManager: Registrado " + orderId + " como " + resolution + " (Intento: " + attempt + ")");
            call.resolve();
        } else {
            call.reject("Failed to save resolved state via commit()");
        }
    }

    @PluginMethod
    public void stopRideAlert(PluginCall call) {
        String orderId = call.getString("orderId");
        String reason = call.getString("reason", "Sin especificar en JS");
        
        Log.e("PushDiagnostic", "ForegroundServicePlugin.stopRideAlert INVOCADO DESDE JS. OrderId: " + orderId + ", Reason: " + reason);
        
        if (orderId != null) {
            if ("all".equals(orderId)) {
                RideAlertController.getInstance().stopAllAlerts(getContext(), "JS Plugin: " + reason);
            } else {
                RideAlertController.getInstance().stopAlert(getContext(), orderId, "JS Plugin: " + reason);
            }
        }
        call.resolve();
    }

    @PluginMethod
    public void startService(PluginCall call) {
        Log.e("PushDiagnostic", "ForegroundServicePlugin: startService() llamado desde React JS");
        try {
            Intent intent = new Intent(getContext(), DriverForegroundService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ContextCompat.startForegroundService(getContext(), intent);
            } else {
                getContext().startService(intent);
            }
            Log.e("PushDiagnostic", "ForegroundServicePlugin: Android aceptó e inició el servicio correctamente");
            call.resolve();
        } catch (Exception e) {
            Log.e("PushDiagnostic", "ForegroundServicePlugin: ERROR al iniciar servicio - " + e.getMessage());
            call.reject("Error starting service", e);
        }
    }

    @PluginMethod
    public void requestBatteryExemption(PluginCall call) {
        Context context = getContext();
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!pm.isIgnoringBatteryOptimizations(context.getPackageName())) {
                try {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    intent.setData(Uri.parse("package:" + context.getPackageName()));
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                } catch (Exception e) {
                    Log.e("PushDiagnostic", "Error solicitando exención de batería", e);
                }
            }
        }
        call.resolve();
    }

    @PluginMethod
    public void requestFullScreenIntentPermission(PluginCall call) {
        Context context = getContext();
        if (Build.VERSION.SDK_INT >= 34) { // Android 14
            android.app.NotificationManager nm = (android.app.NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && !nm.canUseFullScreenIntent()) {
                try {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT);
                    intent.setData(Uri.parse("package:" + context.getPackageName()));
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                } catch (Exception e) {
                    Log.e("PushDiagnostic", "Error solicitando full screen intent", e);
                }
            }
        }
        call.resolve();
    }

    @PluginMethod
    public void requestOverlayPermission(PluginCall call) {
        Context context = getContext();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(context)) {
                try {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + context.getPackageName()));
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                } catch (Exception e) {
                    Log.e("PushDiagnostic", "Error solicitando superposición", e);
                }
            }
        }
        call.resolve();
    }

    @PluginMethod
    public void stopService(PluginCall call) {
        Log.e("PushDiagnostic", "ForegroundServicePlugin: stopService() llamado desde React JS");
        try {
            Intent intent = new Intent(getContext(), DriverForegroundService.class);
            getContext().stopService(intent);
            Log.e("PushDiagnostic", "ForegroundServicePlugin: Android detuvo el servicio");
            call.resolve();
        } catch (Exception e) {
            Log.e("PushDiagnostic", "ForegroundServicePlugin: ERROR al detener servicio - " + e.getMessage());
            call.reject("Error stopping service", e);
        }
    }
}