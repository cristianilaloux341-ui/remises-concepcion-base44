package com.remisesconcepcion.driver;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.PowerManager;
import android.os.Vibrator;
import android.util.Log;
import androidx.core.app.NotificationCompat;

public class RideAlertController {
    private static final String TAG = "RideAlertController";
    
    private static RideAlertController instance;
    private String currentOrderId;
    private MediaPlayer mediaPlayer;
    private Vibrator vibrator;
    private Handler timeoutHandler = new Handler(Looper.getMainLooper());
    private Runnable timeoutRunnable;

    private RideAlertController() {}

    public static synchronized RideAlertController getInstance() {
        if (instance == null) {
            instance = new RideAlertController();
        }
        return instance;
    }

    public synchronized boolean startAlert(final Context context, final String orderId, String title, String body, Intent acceptIntent, Intent rejectIntent, final Intent openAppIntent) {
        currentAlertInstanceId = java.util.UUID.randomUUID().toString();
        Log.e(TAG, "==== START ALERT INVOCADO ====\n" +
                "Instancia: " + currentAlertInstanceId + "\n" +
                "OrderID: " + orderId + "\n" +
                "Hilo: " + Thread.currentThread().getName());
        stopAllAlerts(context, "Nuevo viaje entrante");
        currentOrderId = orderId;
        
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        String channelId = "ride_alerts_urgent_v19"; 

        int soundResId = context.getResources().getIdentifier("horn", "raw", context.getPackageName());
        Uri soundUri;
        if (soundResId != 0) {
            soundUri = Uri.parse("android.resource://" + context.getPackageName() + "/" + soundResId);
        } else {
            soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    channelId,
                    "Alertas de Viaje",
                    NotificationManager.IMPORTANCE_HIGH
            );
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .build();
            if (soundUri != null) {
                channel.setSound(soundUri, audioAttributes);
            }
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 500, 200, 500, 200, 1000});
            channel.setBypassDnd(true);
            channel.setLockscreenVisibility(android.app.Notification.VISIBILITY_PUBLIC);
            notificationManager.createNotificationChannel(channel);
        }

        int reqCode = orderId != null ? orderId.hashCode() : 0;
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;

        PendingIntent acceptPendingIntent = PendingIntent.getBroadcast(context, reqCode, acceptIntent, flags);
        PendingIntent rejectPendingIntent = PendingIntent.getBroadcast(context, reqCode + 1, rejectIntent, flags);
        PendingIntent openAppPendingIntent = PendingIntent.getActivity(context, reqCode + 2, openAppIntent, flags);
        
        Intent dismissIntent = new Intent(context, NotificationActionReceiver.class);
        dismissIntent.setAction("ACTION_DISMISS");
        dismissIntent.putExtra("orderId", orderId);
        PendingIntent dismissPendingIntent = PendingIntent.getBroadcast(context, reqCode + 3, dismissIntent, flags);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setOngoing(true)
                .setAutoCancel(false)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                // Tocar el cuerpo/burbuja de la notificación equivale a ACEPTAR.
                // El full-screen automático sólo muestra la oferta: no debe autoaceptar sin toque.
                .setContentIntent(acceptPendingIntent)
                .setFullScreenIntent(openAppPendingIntent, true)
                .setDeleteIntent(dismissPendingIntent)
                .addAction(0, "✅ ACEPTAR", acceptPendingIntent)
                .addAction(0, "❌ RECHAZAR", rejectPendingIntent);

        if (soundUri != null) {
            builder.setSound(soundUri);
        }
        builder.setVibrate(new long[]{0, 500, 200, 500, 200, 1000});

        // Despertar la pantalla explícitamente
        try {
            android.os.PowerManager pm = (android.os.PowerManager) context.getSystemService(Context.POWER_SERVICE);
            if (pm != null && !pm.isInteractive()) {
                @SuppressWarnings("deprecation")
                android.os.PowerManager.WakeLock wl = pm.newWakeLock(
                        android.os.PowerManager.FULL_WAKE_LOCK | 
                        android.os.PowerManager.ACQUIRE_CAUSES_WAKEUP | 
                        android.os.PowerManager.ON_AFTER_RELEASE, 
                        TAG + ":WakeLock"
                );
                wl.acquire(5000);
            }
        } catch (Exception e) {}

        android.app.Notification notification = builder.build();
        notification.flags |= android.app.Notification.FLAG_INSISTENT;

        try {
            // ALERT_PRESENTED sólo se informa si Android realmente admite publicar
            // la notificación y el canal urgente no está bloqueado.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && !notificationManager.areNotificationsEnabled()) {
                Log.e(TAG, "ALERT_NOT_PRESENTED - notificaciones deshabilitadas para la app");
                currentOrderId = null;
                return false;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel activeChannel = notificationManager.getNotificationChannel(channelId);
                if (activeChannel != null && activeChannel.getImportance() == NotificationManager.IMPORTANCE_NONE) {
                    Log.e(TAG, "ALERT_NOT_PRESENTED - canal de viajes deshabilitado");
                    currentOrderId = null;
                    return false;
                }
            }

            notificationManager.notify(reqCode, notification);
            Log.e(TAG, "FCM_NOTIFICATION_CREATED - ID " + reqCode + " WITH FLAG_INSISTENT");
        } catch (Exception e) {
            Log.e(TAG, "ALERT_NOT_PRESENTED - Android rechazó la publicación", e);
            currentOrderId = null;
            return false;
        }

        // Segundo camino de audio, independiente del sonido del canal. Si Android
        // deja sonar la notificación, ambos caminos apuntan al mismo horn; si el
        // canal falla/silencia el sonido, MediaPlayer intenta mantener el aviso.
        startPersistentAudio(context);

        // Failsafe local contado desde la publicación real. El servidor conserva
        // la autoridad a 30 s y normalmente enviará cancelación/reasignación antes.
        timeoutRunnable = new Runnable() {
            @Override
            public void run() {
                stopAlert(context, orderId, "Vencimiento de failsafe nativo posterior a ALERT_PRESENTED");
            }
        };
        timeoutHandler.postDelayed(timeoutRunnable, 35000);
        return true;
    }

    private String currentAlertInstanceId;

    public synchronized void stopAlert(Context context, String orderId, String reason) {
        Log.e(TAG, "==== STOP ALERT INVOCADO ====\n" +
                "Instancia: " + currentAlertInstanceId + "\n" +
                "OrderID: " + orderId + "\n" +
                "Motivo: " + reason + "\n" +
                "Hilo: " + Thread.currentThread().getName() + "\n" +
                Log.getStackTraceString(new Throwable()));
                
        if (orderId == null || currentOrderId == null) return;
        // La cancelación puede llegar con el intento NUEVO (_att_N) mientras este
        // teléfono conserva la alerta del intento anterior. Comparar el ID real del
        // viaje y cancelar la notificación que efectivamente está activa.
        if (!baseOrderId(orderId).equals(baseOrderId(currentOrderId))) return;
        executeStop(context, currentOrderId);
    }

    public synchronized void stopAllAlerts(Context context, String reason) {
        Log.e(TAG, "==== STOP ALL ALERTS INVOCADO ====\n" +
                "Instancia: " + currentAlertInstanceId + "\n" +
                "Motivo: " + reason + "\n" +
                "Hilo: " + Thread.currentThread().getName() + "\n" +
                Log.getStackTraceString(new Throwable()));
                
        if (currentOrderId != null) {
            executeStop(context, currentOrderId);
        }
    }

    private void executeStop(Context context, String orderId) {
        Log.e(TAG, "==== EXECUTE STOP INVOCADO ====\n" +
                "Instancia: " + currentAlertInstanceId + "\n" +
                "OrderID: " + orderId + "\n" +
                "Hilo: " + Thread.currentThread().getName() + "\n" +
                Log.getStackTraceString(new Throwable()));
        if (timeoutRunnable != null) {
            timeoutHandler.removeCallbacks(timeoutRunnable);
            timeoutRunnable = null;
        }

        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                mediaPlayer.release();
            } catch (Exception e) {
                Log.e(TAG, "Error deteniendo MediaPlayer de alerta", e);
            } finally {
                mediaPlayer = null;
            }
        }

        if (vibrator != null) {
            try { vibrator.cancel(); } catch (Exception e) {
                Log.e(TAG, "Error deteniendo vibración de alerta", e);
            }
            vibrator = null;
        }

        if (orderId != null) {
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.cancel(orderId.hashCode());
        }
        currentOrderId = null;
    }

    /**
     * Refuerzo usado por MainActivity cuando el full-screen logra abrirse.
     * No crea otra alerta ni otro reloj: sólo asegura audio para la oferta activa.
     */
    public synchronized void playAudioFallback(Context context) {
        if (currentOrderId == null) return;
        try {
            if (mediaPlayer != null && mediaPlayer.isPlaying()) return;
        } catch (Exception ignored) {}
        startPersistentAudio(context);
    }

    private synchronized void startPersistentAudio(Context context) {
        if (currentOrderId == null) return;

        try {
            if (mediaPlayer != null) {
                try {
                    if (mediaPlayer.isPlaying()) return;
                    mediaPlayer.release();
                } catch (Exception ignored) {}
                mediaPlayer = null;
            }

            int soundResId = context.getResources().getIdentifier("horn", "raw", context.getPackageName());
            Uri soundUri = soundResId != 0
                    ? Uri.parse("android.resource://" + context.getPackageName() + "/" + soundResId)
                    : RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (soundUri == null) return;

            android.media.AudioManager audioManager =
                    (android.media.AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
            if (audioManager != null) {
                try {
                    audioManager.requestAudioFocus(
                            null,
                            android.media.AudioManager.STREAM_ALARM,
                            android.media.AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE);
                } catch (Exception e) {
                    Log.e(TAG, "No se pudo obtener AudioFocus de alarma", e);
                }
            }

            MediaPlayer nextPlayer = new MediaPlayer();
            nextPlayer.setWakeMode(context, PowerManager.PARTIAL_WAKE_LOCK);
            nextPlayer.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            nextPlayer.setDataSource(context, soundUri);
            nextPlayer.setLooping(true);
            nextPlayer.setVolume(1.0f, 1.0f);
            nextPlayer.prepare();
            nextPlayer.start();
            mediaPlayer = nextPlayer;

            vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null) {
                long[] pattern = {0, 500, 200, 500, 200, 1000};
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0));
                } else {
                    vibrator.vibrate(pattern, 0);
                }
            }

            Log.e(TAG, "AUDIO_FALLBACK_ACTIVE - horn persistente para " + currentOrderId);
        } catch (Exception e) {
            Log.e(TAG, "No se pudo iniciar audio fallback persistente", e);
            if (mediaPlayer != null) {
                try { mediaPlayer.release(); } catch (Exception ignored) {}
                mediaPlayer = null;
            }
            // El sonido del NotificationChannel + FLAG_INSISTENT sigue siendo el
            // camino primario si este refuerzo no puede arrancar.
        }
    }

    private String baseOrderId(String orderId) {
        if (orderId == null) return "";
        return orderId.replaceFirst("_att_\\d+$", "");
    }

    public synchronized boolean isAlertActive(String orderId) {
        return orderId != null && currentOrderId != null &&
                baseOrderId(orderId).equals(baseOrderId(currentOrderId));
    }

    public synchronized void playOneShotSound(Context context, String type) {
        try {
            String fileName = "message";
            if ("cancel".equals(type)) fileName = "cancel";
            if ("bocina".equals(type)) fileName = "horn";
            if ("viaje_iniciado".equals(type)) fileName = "trip_started";
            
            int soundResId = context.getResources().getIdentifier(fileName, "raw", context.getPackageName());
            if (soundResId == 0) return;
            
            Uri soundUri = Uri.parse("android.resource://" + context.getPackageName() + "/" + soundResId);
            MediaPlayer mp = new MediaPlayer();
            mp.setDataSource(context, soundUri);
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            mp.setOnCompletionListener(MediaPlayer::release);
            mp.prepare();
            mp.start();
        } catch (Exception e) {}
    }
}