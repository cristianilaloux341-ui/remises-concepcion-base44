package com.remisesconcepcion.driver;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import androidx.annotation.NonNull;
import com.capacitorjs.plugins.pushnotifications.MessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;

public class MyFirebaseMessagingService extends MessagingService {
    private static final String TAG = "PushDiagnostic";

    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        Log.e(TAG, "==== LLEGO EL PUSH A ANDROID NATIVO ====");
        Log.e(TAG, "FCM_MESSAGE_RECEIVED");
        Log.e(TAG, "Timestamp recepción local: " + System.currentTimeMillis());
        Log.e(TAG, "Message ID: " + remoteMessage.getMessageId());
        Log.e(TAG, "From: " + remoteMessage.getFrom());
        Log.e(TAG, "Collapse Key: " + remoteMessage.getCollapseKey());
        Log.e(TAG, "Priority: " + remoteMessage.getPriority());
        Log.e(TAG, "Original Priority: " + remoteMessage.getOriginalPriority());
        Log.e(TAG, "Sent Time: " + remoteMessage.getSentTime());
        Log.e(TAG, "TTL: " + remoteMessage.getTtl());

        if (remoteMessage.getNotification() != null) {
            Log.e(TAG, "Notification Title: " + remoteMessage.getNotification().getTitle());
            Log.e(TAG, "Notification Body: " + remoteMessage.getNotification().getBody());
        } else {
            Log.e(TAG, "Notification object is NULL (Data-only push)");
        }

        Map<String, String> data = remoteMessage.getData();
        if (data.size() > 0) {
            Log.e(TAG, "Data Completa:");
            for (Map.Entry<String, String> entry : data.entrySet()) {
                Log.e(TAG, "   " + entry.getKey() + " = " + entry.getValue());
            }
        }
        
        String type = data.get("type");
        String orderId = data.get("orderId");

        if ("cancelar".equals(type) || "ride_cancelled".equals(type) || "ride_reassigned".equals(type)) {
            Log.e(TAG, "=> RECIBIDA ORDEN REMOTA DE CIERRE: " + type);
            if (orderId != null) {
                // Registrar resolución para evitar que un push 'ofrecido' demorado suene
                RideStateManager.markResolved(getApplicationContext(), orderId, 999, "CANCELLED");
                RideAlertController.getInstance().stopAlert(getApplicationContext(), orderId, "Comando remoto: " + type);
            }
            RideAlertController.getInstance().playOneShotSound(getApplicationContext(), "cancel");
            return;
        }

        // Parsear assignmentAttempt con try/catch (default 1)
        int incomingAttempt = 1;
        try {
            String attemptStr = data.get("assignmentAttempt");
            if (attemptStr != null && !attemptStr.isEmpty()) {
                incomingAttempt = Integer.parseInt(attemptStr);
            }
        } catch (NumberFormatException e) {
            Log.e(TAG, "assignmentAttempt inválido, usando default 1.");
        }

        boolean isOfferPush = "ofrecido".equals(type) || "broadcast".equals(type);
        
        if (isOfferPush) {
            // 1. La validación de antigüedad por sentAt se removió debido a desincronizaciones de reloj en Android.

            // 2. Validar contra el Gatekeeper de resoluciones locales
            if (orderId != null && RideStateManager.isResolved(getApplicationContext(), orderId, incomingAttempt)) {
                Log.e(TAG, "=> PUSH DE OFERTA DESCARTADO: viaje ya resuelto (intento " + incomingAttempt + ").");
                return;
            }
            
            Log.e(TAG, "Construyendo notificación interactiva nativa para viaje...");
            showInteractiveNotification(data);
            
            // 3. Enviar ACK de recepción (Fire-and-forget) al servidor de forma nativa
            String apiUrl = data.get("apiUrl");
            String driverId = data.get("driverId");
            if (apiUrl != null && orderId != null && driverId != null) {
                String payload = String.format("{\"action\":\"native_ack\", \"orderId\":\"%s\", \"driverId\":\"%s\"}", orderId, driverId);
                sendAckToServer(apiUrl, payload);
            }
        }

        if ("mensaje".equals(type) || "chat".equals(type)) {
            RideAlertController.getInstance().playOneShotSound(getApplicationContext(), "message");
        } else if ("bocina".equals(type) || "viaje_iniciado".equals(type)) {
            RideAlertController.getInstance().playOneShotSound(getApplicationContext(), type);
        }

        Log.e(TAG, "Pasando mensaje al comportamiento original de Capacitor...");
        Log.e(TAG, "==========================================");

        // Llamamos al super de Capacitor para no alterar la lógica en la UI de React
        super.onMessageReceived(remoteMessage);
    }

    private void sendAckToServer(String apiUrl, String jsonPayload) {
        new Thread(() -> {
            try {
                java.net.URL url = new java.net.URL(apiUrl);
                java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                try (java.io.OutputStream os = conn.getOutputStream()) {
                    byte[] input = jsonPayload.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                int code = conn.getResponseCode();
                Log.e(TAG, "ACK de Push enviado nativamente. HTTP " + code);
            } catch (Exception e) {
                Log.e(TAG, "Error enviando ACK nativo", e);
            }
        }).start();
    }

    private void showInteractiveNotification(Map<String, String> data) {
        String orderId = data.get("orderId");
        String driverId = data.get("driverId");
        String driverName = data.get("driverName");
        String base = data.get("base");
        String apiUrl = data.get("apiUrl");
        String title = data.get("title");
        String body = data.get("body");

        if (title == null) title = "🚖 ¡NUEVO VIAJE!";
        if (body == null) body = "Tienes un viaje asignado";

        Context context = getApplicationContext();

        Intent acceptIntent = new Intent(context, NotificationActionReceiver.class);
        acceptIntent.setAction("ACTION_ACCEPT");
        acceptIntent.putExtra("orderId", orderId);
        acceptIntent.putExtra("driverId", driverId);
        acceptIntent.putExtra("driverName", driverName);
        acceptIntent.putExtra("base", base);
        acceptIntent.putExtra("apiUrl", apiUrl);

        Intent rejectIntent = new Intent(context, NotificationActionReceiver.class);
        rejectIntent.setAction("ACTION_REJECT");
        rejectIntent.putExtra("orderId", orderId);
        rejectIntent.putExtra("driverId", driverId);
        rejectIntent.putExtra("apiUrl", apiUrl);

        Intent openAppIntent = new Intent(context, MainActivity.class);
        openAppIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        // Delegar la alerta al controlador centralizado
        RideAlertController.getInstance().startAlert(context, orderId, title, body, acceptIntent, rejectIntent, openAppIntent);
    }

    @Override
    public void onNewToken(@NonNull String s) {
        Log.e(TAG, "==== NUEVO FCM TOKEN ==== " + s);
        super.onNewToken(s);
    }
}